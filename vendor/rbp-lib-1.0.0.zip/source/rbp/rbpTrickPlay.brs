'import "pkg:/source/rbp/rbpUtils.bs"
' ======================================================================
' TRICK PLAY
'
' Speed-ramped scanning with a preview position, committed or cancelled
' by the user.
'
' Entirely pure: state in, state out. Position advances from elapsed
' milliseconds passed in by the caller, never from a clock read here -
' which is what makes the whole ramp assertable without waiting.
'
' Playback is paused while scanning. Roku's own trick play renders
' thumbnails from a BIF file; that is out of scope, so the scrubber shows
' the preview position instead and the video holds a still frame.
' ======================================================================

' Speeds the user steps through, in BOTH directions. Each press of the
' same direction moves one step up and stops at the top.
'
' The number IS seconds of content per second of real time, so this list
' reads directly: 5s, 30s, then 60s per second. It is also what the
' on-screen indicator shows, which is why the label is honest by
' construction - there is no separate display value to drift out of step.
'
' THE LOW END WAS THE BUG. An earlier ramp started at 1x-4x, and on
' anything longer than a few minutes those levels moved the scrubber by
' less than its own thumb width per second. They were indistinguishable
' from a frozen bar, so scanning appeared to do nothing until the top
' speed. A scan speed the user cannot SEE working is not a slow scan, it
' is a broken one.
'
' Key auto-repeat made it worse: holding the key ramps through every
' level in well under a second, so in practice only the top one was ever
' observed. Starting at 5x means the first level is already visibly
' moving, and every level after it is clearly distinct from the last.
'
' 60x crosses a 90-minute film in 90 seconds. Past roughly that the bar
' moves faster than anyone can react to and steering becomes guesswork.
function rbp_trickPlaySpeeds() as object
    return [
        5
        30
        60
    ]
end function

' What the on-screen indicator SHOWS for each step above.
'
' Deliberately not the rate. 5x/30x/60x is the honest multiple, but on a
' remote with three levels it reads as an arbitrary jumble; 2x/3x/4x
' reads as "first, second, third notch", which is the thing the user is
' actually tracking. Roku's own player labels its levels the same way.
'
' The cost of splitting them is that they can drift apart, so
' trickPlayLabelsMatchSpeeds() asserts they stay the same length - an
' index past the end of this list would show nothing at all, silently.
function rbp_trickPlayLabels() as object
    return [
        2
        3
        4
    ]
end function

function rbp_trickPlayLabelsMatchSpeeds() as boolean
    return rbp_trickPlayLabels().count() = rbp_trickPlaySpeeds().count()
end function

function rbp_newTrickPlay() as object
    return {
        active: false
        direction: 0 ' +1 forward, -1 rewind, 0 inactive
        speedIndex: 0
        speed: 0 ' seconds of content per second, drives motion
        displaySpeed: 0 ' what the indicator shows - NOT the rate
        previewPosition: 0 ' where the user would land if they committed
        enteredAt: 0 ' position when scanning began, for cancel
        lastTickMs: 0
    }
end function

' ======================================================================
' KEY HANDLING
'
' Returns { state, action }. Actions:
'
'   none     the key means nothing here
'   enter    scanning began - the caller should pause playback
'   changed  speed or direction changed
'   commit   seek to state.previewPosition, then resume
'   cancel   return to state.enteredAt, then resume
' ======================================================================
function rbp_trickPlayOnKey(state as object, key as string, currentPosition as dynamic, nowMs as integer) as object
    isForward = key = "fastforward"
    isRewind = key = "rewind"
    if isForward or isRewind
        direction = 1
        if isRewind then
            direction = -1
        end if
        return rbp_trickPlayStep(state, direction, currentPosition, nowMs)
    end if
    if not state.active then
        return {
            state: state
            action: "none"
        }
    end if
    ' Committing is deliberately generous: OK, play and the direction the
    ' user is already holding all mean "go there". A user who has found
    ' their spot should not have to hunt for the right button.
    if key = "OK" or key = "play"
        return {
            state: rbp_newTrickPlay()
            action: "commit"
            position: state.previewPosition
        }
    end if
    if key = "back"
        return {
            state: rbp_newTrickPlay()
            action: "cancel"
            position: state.enteredAt
        }
    end if
    return {
        state: state
        action: "none"
    }
end function

function rbp_trickPlayStep(state as object, direction as integer, currentPosition as dynamic, nowMs as integer) as object
    speeds = rbp_trickPlaySpeeds()
    if not state.active
        out = rbp_newTrickPlay()
        out.active = true
        out.direction = direction
        out.speedIndex = 0
        out.speed = speeds[0]
        out.displaySpeed = rbp_trickPlayLabels()[0]
        out.previewPosition = rbp_toPositiveInt(currentPosition)
        out.enteredAt = out.previewPosition
        out.lastTickMs = nowMs
        return {
            state: out
            action: "enter"
        }
    end if
    out = rbp_copyTrickPlay(state)
    if state.direction = direction
        ' Same way again - one step faster, capped at the top.
        if out.speedIndex < speeds.count() - 1 then
            out.speedIndex = out.speedIndex + 1
        end if
    else
        ' The other way. Reset to the slowest speed rather than carrying
        ' the top speed across the reversal, which would overshoot
        ' immediately.
        out.direction = direction
        out.speedIndex = 0
    end if
    out.speed = speeds[out.speedIndex]
    out.displaySpeed = rbp_trickPlayLabels()[out.speedIndex]
    out.lastTickMs = nowMs
    return {
        state: out
        action: "changed"
    }
end function

' ======================================================================
' ADVANCE
'
' Called on a timer while scanning. Elapsed time is passed in rather than
' read, so a full ramp can be asserted in a test without any waiting.
' ======================================================================
function rbp_trickPlayAdvance(state as object, nowMs as integer, duration as dynamic) as object
    if not state.active then
        return state
    end if
    out = rbp_copyTrickPlay(state)
    elapsedMs = nowMs - state.lastTickMs
    if elapsedMs < 0 then
        elapsedMs = 0
    end if
    moved = (elapsedMs / 1000.0) * state.speed * state.direction
    target = state.previewPosition + moved
    ' Clamp one second short of the end for the same reason seeking does:
    ' landing exactly on duration ends playback, which is never what
    ' someone scanning forward is asking for.
    limit = rbp_toPositiveInt(duration)
    if target < 0 then
        target = 0
    end if
    if limit > 0 and target > limit - 1 then
        target = limit - 1
    end if
    out.previewPosition = int(target)
    out.lastTickMs = nowMs
    return out
end function

' True when scanning has run into either end and cannot go further.
' The caller can commit automatically rather than leaving the user
' pressing a key that no longer does anything.
function rbp_trickPlayAtLimit(state as object, duration as dynamic) as boolean
    if not state.active then
        return false
    end if
    limit = rbp_toPositiveInt(duration)
    if state.direction < 0 then
        return state.previewPosition <= 0
    end if
    if limit <= 0 then
        return false
    end if
    return state.previewPosition >= limit - 1
end function

function rbp_copyTrickPlay(state as object) as object
    return {
        active: state.active
        direction: state.direction
        speedIndex: state.speedIndex
        speed: state.speed
        displaySpeed: state.displaySpeed
        previewPosition: state.previewPosition
        enteredAt: state.enteredAt
        lastTickMs: state.lastTickMs
    }
end function
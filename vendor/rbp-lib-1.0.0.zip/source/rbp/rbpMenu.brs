'import "pkg:/source/rbp/rbpUtils.bs"
'import "pkg:/source/rbp/rbpTrack.bs"
' ======================================================================
' TRACK MENU MODEL
'
' Pure. Rows in, rows out, an index that moves. Nothing here knows what a
' node is, which is why the whole of menu navigation is asserted
' off-device before any of it is drawn.
'
' THE HIGHLIGHT IS NOT SCENEGRAPH FOCUS. It is an index in this state,
' rendered as a coloured row. The moment a node inside the SDK becomes
' focusable, the focus-trap problem that shaped the whole of P7 comes
' back: SceneGraph would start deciding where keys go, instead of one
' pure function that can be read in full.
'
' There is no MenuTab enum. The two panes ARE rbp.TrackKind - audio and
' subtitle - so the pane doubles as the value that decides which
' selectTrack call applies the choice. A parallel enum would have been
' two names for one idea, and something to keep in step for no gain.
'
' NOTE `kind`, never `tab`. `tab` is a reserved builtin in BrightScript
' (the TAB() print function) and will not compile as an identifier - the
' same trap that made `stop` unusable as a function name in P2.
' ======================================================================

' The subtitle "Off" row. Empty string is what selectSubtitleTrack()
' already means by "off", so the row needs no special case at the point
' it is applied - it is just another id.
function rbp_subtitleOffId() as string
    return ""
end function

function rbp_newMenu() as object
    return {
        open: false
        kind: "audio"
        index: 0
    }
end function

' ======================================================================
' ROWS
'
' { id, label, selected, selectable }
'
' `selectable` exists for the empty state. A menu opened before the
' manifest has parsed has nothing to list, and a blank panel reads as a
' broken one - so it carries a row that explains itself and cannot be
' chosen.
' ======================================================================
function rbp_menuRow(id as string, label as string, selected as boolean, selectable = true as boolean) as object
    return {
        id: id
        label: label
        selected: selected
        selectable: selectable
    }
end function

function rbp_menuRows(kind as dynamic, tracks as dynamic, currentId as dynamic) as object
    rows = []
    isSubtitle = kind = "subtitle"
    current = ""
    if rbp_isNonEmptyString(currentId) then
        current = currentId
    end if
    ' Subtitles get an Off row, and it comes FIRST. Turning them off is
    ' the most common thing anyone does in this menu, and burying it
    ' under thirteen languages makes the common case the longest one.
    if isSubtitle
        rows.push(rbp_menuRow(rbp_subtitleOffId(), "Off", current = ""))
    end if
    if rbp_isArray(tracks)
        for each track in tracks
            if rbp_isAA(track) and rbp_isNonEmptyString(track.id)
                rows.push(rbp_menuRow(track.id, track.label, track.id = current))
            end if
        end for
    end if
    if rows.count() = 0
        ' Audio only - the subtitle pane always has Off, so it is never
        ' empty. tracksReady is false at this point in practice.
        return [
            rbp_menuRow("", "No audio tracks available", false, false)
        ]
    end if
    return rows
end function

' Index of the row that is currently applied, so opening the menu lands
' the highlight on what is playing rather than at the top. Someone who
' opens the menu to check what is selected should see it immediately.
function rbp_menuSelectedIndex(rows as dynamic) as integer
    if not rbp_isArray(rows) then
        return 0
    end if
    for i = 0 to rows.count() - 1
        if rows[i].selected = true then
            return i
        end if
    end for
    return 0
end function

' ======================================================================
' NAVIGATION
' ======================================================================
function rbp_menuOpen(kind as string, rows as dynamic) as object
    return {
        open: true
        kind: kind
        index: rbp_menuSelectedIndex(rows)
    }
end function

function rbp_menuClose() as object
    return rbp_newMenu()
end function

' Move the highlight. CLAMPS at both ends rather than wrapping.
'
' Wrapping saves a press at the ends of a long subtitle list, but it also
' means one press too many silently teleports the user to the other end
' of a list they were reading carefully. A list that stops where it ends
' is the more predictable of the two, and it matches how the rest of a
' Roku UI behaves.
function rbp_menuMove(state as object, delta as integer, rowCount as dynamic) as object
    count = rbp_toPositiveInt(rowCount)
    out = {
        open: state.open
        kind: state.kind
        index: state.index
    }
    if count <= 0
        out.index = 0
        return out
    end if
    target = state.index + delta
    if target < 0 then
        target = 0
    end if
    if target > count - 1 then
        target = count - 1
    end if
    out.index = target
    return out
end function

' Switching pane re-lands the highlight on that pane's current selection,
' for the same reason opening does. Carrying the old index across would
' point at an unrelated row.
function rbp_menuSwitchKind(state as object, kind as string, rows as dynamic) as object
    return {
        open: state.open
        kind: kind
        index: rbp_menuSelectedIndex(rows)
    }
end function

' The column a horizontal key points at. Spatial, not a toggle: the
' panel draws audio on the left and subtitles on the right, so left
' always means audio and right always means subtitles. A toggle would
' make `left` jump to the right-hand column, which is the wrong way.
function rbp_menuKindToward(direction as integer) as string
    if direction > 0 then
        return "subtitle"
    end if
    return "audio"
end function

' ======================================================================
' SCROLLING
'
' Index of the first row to draw, given how many fit on screen.
'
' Needed because real streams overflow: the Apple advanced test stream
' carries 13 subtitle renditions and roughly 10 rows fit at the default
' token sizes. Without this the list would simply stop at the bottom of
' the panel and the remaining tracks would be unreachable.
'
' STATELESS - it centres the highlight rather than scrolling minimally.
' Minimal scrolling needs the previous window start, which would put a
' layout concern into the menu state and make every move depend on how
' many rows happened to fit. Centring is a function of the index alone,
' so it is deterministic and testable without any of that.
' ======================================================================
function rbp_menuWindowStart(index as dynamic, visibleCount as dynamic, rowCount as dynamic) as integer
    visible = rbp_toPositiveInt(visibleCount)
    count = rbp_toPositiveInt(rowCount)
    i = rbp_toPositiveInt(index)
    ' Everything fits - never scroll.
    if visible <= 0 or count <= visible then
        return 0
    end if
    start = i - int(visible / 2)
    if start < 0 then
        start = 0
    end if
    last = count - visible
    if start > last then
        start = last
    end if
    return start
end function

' The row the user is on, or invalid when there is nothing to choose.
' Returning invalid rather than a blank row keeps the caller from
' applying an empty track id and turning audio off by accident.
function rbp_menuChoice(rows as dynamic, index as dynamic) as object
    if not rbp_isArray(rows) then
        return invalid
    end if
    i = rbp_toPositiveInt(index)
    if i > rows.count() - 1 then
        return invalid
    end if
    row = rows[i]
    if row.selectable <> true then
        return invalid
    end if
    return row
end function
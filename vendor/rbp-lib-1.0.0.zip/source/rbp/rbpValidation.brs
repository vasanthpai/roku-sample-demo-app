'import "pkg:/source/rbp/rbpUtils.bs"
'import "pkg:/source/rbp/rbpStreamFormat.bs"
'import "pkg:/source/rbp/rbpErrorCode.bs"
' Derive a stream format from a url extension.
' Returns "" when it cannot be determined - never guesses.
function rbp_inferFormat(url as dynamic) as string
    if not rbp_isNonEmptyString(url) then
        return ""
    end if
    clean = lCase(url)
    ' Strip query and fragment: ".../master.m3u8?token=abc" must still match
    q = instr(1, clean, "?")
    if q > 0 then
        clean = left(clean, q - 1)
    end if
    h = instr(1, clean, "#")
    if h > 0 then
        clean = left(clean, h - 1)
    end if
    if rbp_endsWith(clean, ".m3u8") then
        return "hls"
    end if
    if rbp_endsWith(clean, ".mpd") then
        return "dash"
    end if
    if rbp_endsWith(clean, ".ism") then
        return "ism"
    end if
    if rbp_endsWith(clean, ".mp4") then
        return "mp4"
    end if
    if rbp_endsWith(clean, ".mov") then
        return "mp4"
    end if
    return ""
end function

function rbp_isSupportedFormat(format as dynamic) as boolean
    if not rbp_isNonEmptyString(format) then
        return false
    end if
    f = lCase(format)
    return f = "hls" or f = "dash" or f = "ism" or f = "mp4"
end function

' Validate a client-supplied media item.
'
' Returns { ok, code, message, format }. On success `format` carries the
' resolved value so the caller does not have to infer it a second time.
function rbp_validateMediaItem(source as dynamic) as object
    if not rbp_isAA(source)
        return rbp_validationFailure("invalidMediaItem", "media item must be an associative array")
    end if
    if not rbp_isNonEmptyString(source.url)
        return rbp_validationFailure("missingUrl", "media item requires a non-empty url")
    end if
    format = source.format
    if not rbp_isNonEmptyString(format)
        format = rbp_inferFormat(source.url)
        if format = ""
            return rbp_validationFailure("unsupportedFormat", "format not supplied and not inferable from the url")
        end if
    else if not rbp_isSupportedFormat(format)
        return rbp_validationFailure("unsupportedFormat", "unsupported format: " + format)
    end if
    return {
        ok: true
        code: "none"
        message: ""
        format: lCase(format)
    }
end function

function rbp_validationFailure(code as string, message as string) as object
    return {
        ok: false
        code: code
        message: message
        format: ""
    }
end function
' The SDK's own playback vocabulary.
'
' Clients branch on these values, never on Roku's raw Video node states.
' That indirection is deliberate: it means a firmware change to Roku's
' state strings is our problem to absorb, not a break in every client app.

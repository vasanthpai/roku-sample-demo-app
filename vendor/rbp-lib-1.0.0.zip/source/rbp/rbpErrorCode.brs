' SDK-level error taxonomy.
'
' P10 maps Roku's numeric errorCode onto these. Clients handle a small,
' stable set of causes instead of Roku's device-specific codes.

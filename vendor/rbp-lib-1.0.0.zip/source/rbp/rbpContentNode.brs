'import "pkg:/source/rbp/rbpUtils.bs"
' The thin wrapper P1's mapper was designed for.
'
' Deliberately trivial: one setFields() call, no branching. That is only
' possible because mapToContent() emits keys that are already exact
' ContentNode field names. If this function ever needs an if-statement,
' the logic belongs back in the mapper where it can be tested as data.
function rbp_toContentNode(content as dynamic) as object
    if not rbp_isAA(content) then
        return invalid
    end if
    node = createObject("roSGNode", "ContentNode")
    if node = invalid then
        return invalid
    end if
    node.setFields(content)
    return node
end function
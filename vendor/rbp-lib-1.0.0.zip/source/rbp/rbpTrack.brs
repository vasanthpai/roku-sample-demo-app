'import "pkg:/source/rbp/rbpUtils.bs"
' ======================================================================
' TRACKS
'
' Roku exposes audio and subtitle tracks as arrays of associative arrays
' on the Video node, with different key names for each kind and no
' guarantee about which keys are present. This normalises them into one
' shape the rest of the SDK and every client can rely on.
'
' Pure functions - arrays in, arrays out. No nodes.
' ======================================================================


' The client-facing shape.
'
'   id        what Roku selects by - opaque, do not parse it
'   language  ISO code where the stream provides one
'   label     human-readable, falls back to the language, then the id
'   kind      audio or subtitle
'
' `raw` is deliberately NOT carried through: it is Roku's shape, it
' varies by firmware and stream, and exposing it would make a client's
' code depend on something we cannot promise.
function rbp_newTrack(id as string, language as string, label as string, kind as string, ordinal = 0 as integer) as object
    resolvedLabel = label
    if resolvedLabel = "" then
        resolvedLabel = language
    end if
    ' Last resort is positional, NOT the id.
    '
    ' Verified on device: a DASH stream reported an audio track with no
    ' name and no language, whose id was "dash/a~AAC~~main~~2~". Falling
    ' back to the id put that string in front of the user. "Audio 1" says
    ' nothing, but it says nothing comprehensibly.
    if resolvedLabel = ""
        if kind = "subtitle"
            resolvedLabel = "Subtitle " + Str(ordinal).Trim()
        else
            resolvedLabel = "Audio " + Str(ordinal).Trim()
        end if
    end if
    return {
        id: id
        language: language
        label: resolvedLabel
        kind: kind
    }
end function

' Normalise one raw Roku track.
'
' Audio and subtitle entries use different keys, and firmware versions
' differ, so every plausible key is tried rather than assuming one shape.
' Returns invalid for anything without a usable id - a track we cannot
' select is worse than no track at all, because it would appear in a menu
' and silently do nothing.
function rbp_normalizeTrack(raw as dynamic, kind as string, ordinal = 0 as integer) as object
    if not rbp_isAA(raw) then
        return invalid
    end if
    id = rbp_firstStringValue(raw, [
        "Track"
        "TrackName"
        "track"
        "id"
    ])
    if id = "" then
        return invalid
    end if
    language = rbp_firstStringValue(raw, [
        "Language"
        "language"
        "lang"
    ])
    label = rbp_firstStringValue(raw, [
        "Name"
        "Description"
        "name"
        "label"
    ])
    return rbp_newTrack(id, language, label, kind, ordinal)
end function

' Normalise a whole list, skipping anything unusable.
function rbp_normalizeTracks(rawList as dynamic, kind as string) as object
    out = []
    if rawList = invalid then
        return out
    end if
    if type(rawList) <> "roArray" and type(rawList) <> "roList" then
        return out
    end if
    ordinal = 0
    for each raw in rawList
        ordinal = ordinal + 1
        track = rbp_normalizeTrack(raw, kind, ordinal)
        if track <> invalid then
            out.push(track)
        end if
    end for
    return rbp_dedupeTracks(out)
end function

' Collapse codec variants of the same programme.
'
' Roku exposes one selectable track per codec and bitrate, so a stream
' carrying two audio programmes at five encodings reports ten tracks with
' two distinct labels. A client building a menu from that shows "English"
' three times with no way to tell which to keep - and selecting a
' different one costs a rebuffer while changing nothing the user can hear,
' because Roku picks the encoding by bandwidth regardless.
'
' The user-facing choice is which programme, not which codec. First wins.
'
' To expose every variant instead, return `tracks` unchanged here and add
' a codec field to the model - the rest of the SDK is unaffected.
function rbp_dedupeTracks(tracks as object) as object
    out = []
    seen = {}
    for each track in tracks
        key = lCase(track.language + "|" + track.label)
        if not seen.doesExist(key)
            seen[key] = true
            out.push(track)
        end if
    end for
    return out
end function

' ======================================================================
' SELECTION
' ======================================================================
function rbp_findTrackById(tracks as dynamic, id as dynamic) as object
    if tracks = invalid or not rbp_isNonEmptyString(id) then
        return invalid
    end if
    for each track in tracks
        if track.id = id then
            return track
        end if
    end for
    return invalid
end function

' Resolve a requested selection against what the stream actually offers.
'
' Returns { ok, id, reason }. An empty id means "none" and is only valid
' where allowNone is true - subtitles can be turned off, audio cannot.
'
' Selecting a track that is not in the list is refused rather than passed
' to Roku, which ignores an unknown id silently and leaves the client
' believing the switch succeeded.
function rbp_resolveTrackSelection(tracks as dynamic, requestedId as dynamic, allowNone as boolean) as object
    isNone = requestedId = invalid or requestedId = ""
    if isNone
        if allowNone then
            return {
                ok: true
                id: ""
                reason: ""
            }
        end if
        return {
            ok: false
            id: ""
            reason: "noneNotAllowed"
        }
    end if
    if not rbp_isNonEmptyString(requestedId)
        return {
            ok: false
            id: ""
            reason: "invalidTrackId"
        }
    end if
    if tracks = invalid or tracks.count() = 0
        return {
            ok: false
            id: ""
            reason: "noTracksAvailable"
        }
    end if
    if rbp_findTrackById(tracks, requestedId) = invalid
        return {
            ok: false
            id: ""
            reason: "unknownTrack"
        }
    end if
    return {
        ok: true
        id: requestedId
        reason: ""
    }
end function

' ======================================================================
' CHANGE DETECTION
'
' Roku reports track lists more than once as a manifest parses, often
' with identical content. An assocarray or array field notifies on EVERY
' assignment - SceneGraph does not compare values the way it does for
' strings - so republishing an unchanged list wakes the client for
' nothing and, worse, would make a menu rebuild under the user.
'
' Learned in P4 from sessionStats doing exactly that.
' ======================================================================
function rbp_tracksEqual(a as dynamic, b as dynamic) as boolean
    if a = invalid and b = invalid then
        return true
    end if
    if a = invalid or b = invalid then
        return false
    end if
    if a.count() <> b.count() then
        return false
    end if
    for i = 0 to a.count() - 1
        if a[i].id <> b[i].id then
            return false
        end if
        if a[i].label <> b[i].label then
            return false
        end if
        if a[i].language <> b[i].language then
            return false
        end if
    end for
    return true
end function
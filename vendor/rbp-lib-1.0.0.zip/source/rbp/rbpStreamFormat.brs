' Values Roku's Video node accepts for ContentNode.streamFormat.
' Kept as an enum so a typo is a compile error rather than a stream that
' silently refuses to play.

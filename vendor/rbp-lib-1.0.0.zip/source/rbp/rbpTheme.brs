'import "pkg:/source/rbp/rbpUtils.bs"
' ======================================================================
' THEME
'
' Clients brand the player by sending a partial set of tokens. Everything
' they omit keeps its default.
'
' Pure functions - maps in, maps out. Nothing here touches a node, which
' is why the whole merge is testable off-device.
' ======================================================================

' The complete token set.
'
' Colours are stored in Roku's 0xRRGGBBAA form. Clients may send CSS-style
' hex; resolveTheme() normalises it.
function rbp_defaultTheme() as object
    return {
        colors: {
            primary: "0x3FBAC3FF" ' scrubber fill, focus ring
            background: "0x000000FF" ' behind the video
            surface: "0x101418F2" ' control bar
            text: "0xFFFFFFFF"
            textMuted: "0x9AA6B2FF"
            overlay: "0x000000B3" ' scrim behind controls
            error: "0xE5484DFF"
        }
        fonts: {
            ' "" uses the Roku system font. A custom face must be an
            ' HTTP(S) url to a .ttf or .otf - see the assets note below.
            family: ""
            titleSize: 34
            bodySize: 24
            captionSize: 18
        }
        spacing: {
            unit: 8
            barPadding: 24
            gap: 16
        }
        sizes: {
            controlBarHeight: 140
            scrubberHeight: 8
            iconSize: 48
        }
        ' What the overlay draws at all. A client turning a section off
        ' gets the space back - the layout closes up rather than leaving
        ' a hole where the section used to be.
        controls: {
            showIcons: true ' play/pause + skip glyphs
            showTimes: true ' elapsed and remaining
            showScrubber: true ' progress track
            showRatingBug: true ' age rating, top-left, at the start
            ratingBugSeconds: 10 ' 0 keeps it up for the whole stream
            ' OFF by default. Most apps already show the title on the
            ' screen that launched playback, and repeating it inside the
            ' player is duplication the client cannot remove. A client
            ' whose player is the whole experience turns it on and gets
            ' it top-left, above the rating - never down by the bar,
            ' where it crowds the controls.
            showTitle: false
            ' The SDK's own audio/subtitle menu on the * key. Turn it off
            ' and * bubbles to the client untouched, so a client building
            ' their own menu from audioTracks/subtitleTracks gets the key
            ' back rather than fighting the SDK for it.
            showMenus: true
        }
        ' Every asset is a URL, never a pkg:/ path. See validateAsset().
        '
        ' The icon entries OVERRIDE the SDK's own bundled glyphs, which
        ' are white alpha masks tinted from colors.text. A client icon is
        ' drawn exactly as supplied - it keeps its own colours, because
        ' tinting someone's branded artwork to a flat colour destroys it.
        assets: {
            logo: ""
            iconPlay: ""
            iconPause: ""
            iconRewind: ""
            iconForward: ""
            iconCaptions: ""
            iconAudio: ""
        }
    }
end function
' ======================================================================
' MERGE
' ======================================================================

' Resolve a client's partial overrides against the defaults.
'
' Returns { theme, warnings }. A bad value never fails the whole theme -
' the default is kept and a warning records what was rejected, because a
' player that refuses to start over one malformed icon url is worse than
' one that starts with the default icon.
' The canonical spelling of every validated token.
'
' These exist because a BrightScript associative array LOWERCASES its
' keys: `for each key in theme.colors` yields "textmuted", never
' "textMuted". Building a warning path by concatenating that key produced
' `assets.iconplay`, which a client searching their own theme for
' `iconPlay` would never find. An array of strings keeps its case.
'
' Iterating this list rather than the map has a second effect, and it is
' the documented one: a token the SDK does not know about now passes
' through genuinely untouched. The old loop validated unknown client keys
' as if they were colours and reset them to invalid.
'
' themeTokensAreCovered() asserts this list matches defaultTheme(), so a
' token added without its name here fails a spec rather than silently
' losing validation.
function rbp_themeTokenNames() as object
    return {
        colors: [
            "primary"
            "background"
            "surface"
            "text"
            "textMuted"
            "overlay"
            "error"
        ]
        assets: [
            "logo"
            "iconPlay"
            "iconPause"
            "iconRewind"
            "iconForward"
            "iconCaptions"
            "iconAudio"
        ]
        controls: [
            "showIcons"
            "showTimes"
            "showScrubber"
            "showRatingBug"
            "ratingBugSeconds"
            "showTitle"
            "showMenus"
        ]
    }
end function

' True when every name above resolves to a real default AND every default
' has a name. Map lookup is case-insensitive, so a misspelling is caught
' by the lookup and a missing entry by the count.
function rbp_themeTokensAreCovered() as boolean
    defaults = rbp_defaultTheme()
    names = rbp_themeTokenNames()
    for each group in [
        "colors"
        "assets"
        "controls"
    ]
        if names[group].count() <> defaults[group].count() then
            return false
        end if
        for each name in names[group]
            if defaults[group][name] = invalid then
                return false
            end if
        end for
    end for
    return true
end function

function rbp_resolveTheme(overrides as dynamic) as object
    warnings = []
    theme = rbp_mergeDeep(rbp_defaultTheme(), overrides)
    defaults = rbp_defaultTheme()
    names = rbp_themeTokenNames()
    ' Colours: accept CSS-style hex, store Roku's form.
    for each key in names.colors
        resolved = rbp_toRokuColor(theme.colors[key], "")
        if resolved = ""
            warnings.push({
                path: "colors." + key
                reason: "invalidColor"
            })
            theme.colors[key] = defaults.colors[key]
        else
            theme.colors[key] = resolved
        end if
    end for
    ' Assets must be reachable URLs.
    for each key in names.assets
        check = rbp_validateAsset(theme.assets[key])
        if not check.ok
            warnings.push({
                path: "assets." + key
                reason: check.reason
            })
            theme.assets[key] = ""
        end if
    end for
    ' Control toggles. A non-boolean here would silently make a section
    ' vanish, so a bad value is reported and defaulted like any other.
    for each key in names.controls
        expected = defaults.controls[key]
        value = theme.controls[key]
        if rbp_isBoolean(expected)
            if not rbp_isBoolean(value)
                warnings.push({
                    path: "controls." + key
                    reason: "notBoolean"
                })
                theme.controls[key] = expected
            end if
        else
            if not rbp_isNumeric(value) or value < 0
                warnings.push({
                    path: "controls." + key
                    reason: "notPositiveNumber"
                })
                theme.controls[key] = expected
            end if
        end if
    end for
    if rbp_isNonEmptyString(theme.fonts.family)
        check = rbp_validateAsset(theme.fonts.family)
        if not check.ok
            warnings.push({
                path: "fonts.family"
                reason: check.reason
            })
            theme.fonts.family = ""
        end if
    end if
    return {
        theme: theme
        warnings: warnings
    }
end function

' Recursive merge. A nested map merges key by key; anything else replaces.
'
' This is why a client sending one colour keeps every other token. A
' shallow merge would replace the whole `colors` map and leave the player
' with a single defined colour and no text.
'
' Unknown keys pass through untouched, so a client may carry tokens the
' SDK does not know about yet.
function rbp_mergeDeep(base as object, overrides as dynamic) as object
    out = rbp_cloneMap(base)
    if not rbp_isAA(overrides) then
        return out
    end if
    for each key in overrides
        value = overrides[key]
        if rbp_isAA(value) and rbp_isAA(out[key])
            out[key] = rbp_mergeDeep(out[key], value)
        else
            out[key] = value
        end if
    end for
    return out
end function

' Deep copy. Without it a nested merge would mutate the defaults, and the
' second client to apply a theme would inherit the first one's colours.
function rbp_cloneMap(source as object) as object
    out = {}
    for each key in source
        value = source[key]
        if rbp_isAA(value)
            out[key] = rbp_cloneMap(value)
        else
            out[key] = value
        end if
    end for
    return out
end function
' ======================================================================
' COLOUR
' ======================================================================

' Normalise a colour to Roku's 0xRRGGBBAA.
'
' Accepts #RGB, #RRGGBB, #RRGGBBAA, and the same forms with 0x or no
' prefix. Returns the fallback for anything it cannot parse.
'
' Roku requires the alpha byte. A client sending "#E50914" without this
' would get a colour Roku reads as transparent or wrong - a silent
' rendering failure with no error anywhere.
function rbp_toRokuColor(value as dynamic, fallback as string) as string
    if not rbp_isNonEmptyString(value) then
        return fallback
    end if
    digits = value.trim()
    if left(digits, 1) = "#"
        digits = mid(digits, 2)
    else if lCase(left(digits, 2)) = "0x"
        digits = mid(digits, 3)
    end if
    ' #RGB shorthand
    if len(digits) = 3
        r = mid(digits, 1, 1)
        g = mid(digits, 2, 1)
        b = mid(digits, 3, 1)
        digits = r + r + g + g + b + b
    end if
    ' Opaque unless the client said otherwise
    if len(digits) = 6 then
        digits = digits + "FF"
    end if
    if len(digits) <> 8 then
        return fallback
    end if
    if not rbp_isHexString(digits) then
        return fallback
    end if
    return "0x" + uCase(digits)
end function

function rbp_isHexString(value as string) as boolean
    if len(value) = 0 then
        return false
    end if
    for i = 1 to len(value)
        if instr(1, "0123456789abcdefABCDEF", mid(value, i, 1)) = 0 then
            return false
        end if
    end for
    return true
end function
' ======================================================================
' ASSETS
' ======================================================================

' Validate a client-supplied asset url.
'
' A pkg:/ path is REFUSED, not merely ignored. Inside a ComponentLibrary
' pkg:/ resolves to the library's own package, not the client's - so a
' client pointing at their own bundled logo gets nothing on screen, no
' error, and no way to work out why. Telling them is the only way they
' find out.
'
' An empty value is valid: it means "use the default".
function rbp_validateAsset(url as dynamic) as object
    if url = invalid or url = "" then
        return {
            ok: true
            reason: ""
        }
    end if
    if not rbp_isNonEmptyString(url) then
        return {
            ok: false
            reason: "invalidAsset"
        }
    end if
    lower = lCase(url.trim())
    if left(lower, 5) = "pkg:/"
        return {
            ok: false
            reason: "pkgPathNotSupported"
        }
    end if
    if left(lower, 7) <> "http://" and left(lower, 8) <> "https://"
        return {
            ok: false
            reason: "urlRequired"
        }
    end if
    return {
        ok: true
        reason: ""
    }
end function
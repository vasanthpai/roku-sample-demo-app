'import "pkg:/source/rbp/rbpUtils.bs"
'import "pkg:/source/rbp/rbpKeyRoute.bs"
' ======================================================================
' BUTTON ROW
'
' The row under the progress bar: rewind, play/pause, forward, then the
' Audio & Subtitles button at the far right. `down` lands on it, left and
' right walk along it, OK activates whatever is highlighted.
'
' Pure. Which buttons exist, where focus lands, how it moves and what OK
' does are all decided here, off-device. The overlay only draws the
' result, and nothing in it is SceneGraph-focusable.
'
' Why this does not bring back the P7 focus trap: the trap needs ONE row
' that owns both the horizontal keys and the only way out. Here the
' progress bar owns left/right as skip, this row owns them as movement,
' and up/down move between the two - so every row always has an exit.
' ======================================================================


' Which buttons exist, left to right, given the client's toggles.
'
' The transport buttons follow controls.showIcons and the tracks button
' follows controls.showMenus - so a client who hides the glyphs is not
' left with three invisible stops to press through, and a client who
' turns the menu off does not get a button that opens nothing.
function rbp_buttonRowItems(showIcons as boolean, showMenus as boolean) as object
    items = []
    if showIcons
        items.push("rewind")
        items.push("playPause")
        items.push("forward")
    end if
    if showMenus then
        items.push("tracks")
    end if
    return items
end function

' Where `down` lands. Play/pause, because it is the button anyone
' entering the row is most likely to want - and it sits in the middle, so
' either neighbour is one press away.
function rbp_buttonRowEntryIndex(items as dynamic) as integer
    if not rbp_isArray(items) then
        return 0
    end if
    for i = 0 to items.count() - 1
        if items[i] = "playPause" then
            return i
        end if
    end for
    return 0
end function

' Move along the row. CLAMPS at both ends, like the track panel: one
' press too many should not throw focus to the far end of the row.
function rbp_buttonRowMove(index as dynamic, delta as integer, count as dynamic) as integer
    n = rbp_toPositiveInt(count)
    if n <= 0 then
        return 0
    end if
    target = rbp_toPositiveInt(index) + delta
    if target < 0 then
        target = 0
    end if
    if target > n - 1 then
        target = n - 1
    end if
    return target
end function

' The button under the highlight, or "" when there is none.
function rbp_buttonRowAt(items as dynamic, index as dynamic) as string
    if not rbp_isArray(items) then
        return ""
    end if
    i = rbp_toPositiveInt(index)
    if i > items.count() - 1 then
        return ""
    end if
    return items[i]
end function

' What OK does on each button - expressed as the KeyAction the transport
' row already understands, so there is exactly one implementation of
' "skip back" whether it came from left on the bar or OK on this button.
'
' Rewind and forward SKIP, they do not scan. Inside trick play OK means
' "stop here", so if OK on the forward button started a scan, the second
' OK would end it rather than speed it up: one key meaning two opposite
' things depending on state the user cannot see. Scanning stays on the
' dedicated rewind and fastforward keys, which is also where every
' mainstream TV player keeps it.
function rbp_buttonAction(button as dynamic) as string
    if button = "rewind" then
        return "skipBack"
    end if
    if button = "playPause" then
        return "togglePlayPause"
    end if
    if button = "forward" then
        return "skipForward"
    end if
    if button = "tracks" then
        return "openMenu"
    end if
    return "none"
end function
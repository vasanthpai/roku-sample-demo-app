'import "pkg:/source/rbp/rbpUtils.bs"
' ======================================================================
' SCRUBBER GEOMETRY
'
' Pure. Positions and widths in, pixels out.
' ======================================================================

' Fraction of the way through, 0.0 to 1.0.
' An unknown duration reads as 0 rather than dividing by zero.
function rbp_progressFraction(position as dynamic, duration as dynamic) as float
    total = rbp_toPositiveInt(duration)
    if total <= 0 then
        return 0.0
    end if
    current = rbp_toPositiveInt(position)
    if current <= 0 then
        return 0.0
    end if
    if current >= total then
        return 1.0
    end if
    return current / (total * 1.0)
end function

' Filled width of the bar, in pixels.
function rbp_fillWidth(position as dynamic, duration as dynamic, barWidth as dynamic) as integer
    width = rbp_toPositiveInt(barWidth)
    if width <= 0 then
        return 0
    end if
    return int(rbp_progressFraction(position, duration) * width)
end function

' Centre of the thumb, in pixels from the left of the bar.
'
' Inset by half the thumb so it never hangs off either end - at position
' zero the thumb sits fully inside the track, not straddling its edge.
function rbp_thumbX(position as dynamic, duration as dynamic, barWidth as dynamic, thumbWidth as dynamic) as integer
    width = rbp_toPositiveInt(barWidth)
    thumb = rbp_toPositiveInt(thumbWidth)
    if width <= 0 then
        return 0
    end if
    travel = width - thumb
    if travel < 0 then
        travel = 0
    end if
    return int(thumb / 2) + int(rbp_progressFraction(position, duration) * travel)
end function

' Where a skip lands.
'
' Clamped to the stream, and one second short of the end for the same
' reason seeking is: landing exactly on duration ends playback, which is
' never what someone skipping forward is asking for.
function rbp_skipTarget(position as dynamic, duration as dynamic, deltaSeconds as dynamic) as integer
    target = rbp_toPositiveInt(position) + rbp_toSafeNumber(deltaSeconds)
    if target < 0 then
        target = 0
    end if
    limit = rbp_toPositiveInt(duration)
    if limit > 0 and target > limit - 1 then
        target = limit - 1
    end if
    if target < 0 then
        target = 0
    end if
    return int(target)
end function
'import "pkg:/source/rbp/rbpUtils.bs"
' ======================================================================
' KEY ROUTING
'
' One pure function decides what every key means, given the context the
' player is in. No component ever holds SceneGraph focus, and no node
' handles keys for itself.
'
' Why centralised:
'
'   - it is a table, so every key in every context is a spec
'   - nothing inside the player can steal focus from the client's own UI
'   - P9's menus become a new context, not a re-plumbing exercise
'
' Why no SceneGraph focus anywhere: on Roku, left/right in a player
' skip. If a focusable scrubber captured them, there would be no way to
' leave it.
'
' The overlay does have TWO ROWS the user can be "on" - the transport row
' (scrubber, skip) and the button row beneath it - but that is state in
' this table, not SceneGraph focus. up and down move between the rows,
' and left/right mean something different in each. That is what makes a
' button row safe here: the trap only exists when one row owns both the
' horizontal keys AND the only way out.
' ======================================================================

' Actions the caller carries out. Named for intent, not for the key that
' produced them, so the table can be re-bound without touching the player.


' Resolve a key press.
'
' Returns { action, handled }. `handled` tells the caller whether to
' consume the key: returning false lets it bubble, which is how `back`
' eventually exits the channel instead of trapping the user.
' menusEnabled is the client's controls.showMenus token. When false,
' `options` BUBBLES rather than being swallowed - a client who turned the
' SDK menu off wants that key back, not a button that silently does
' nothing.
'
' buttonRowAvailable is whether the row under the bar has any buttons at
' all. It is separate from menusEnabled because the row can exist
' without the menu (the transport buttons alone) and the menu without
' the glyphs. When the row is empty, `down` bubbles for the same reason.
'
' Both default to true so every existing caller and spec keeps working.
function rbp_resolveKey(context as dynamic, key as dynamic, overlayVisible as boolean, menusEnabled = true as boolean, buttonRowAvailable = true as boolean) as object
    if not rbp_isNonEmptyString(key) then
        return rbp_keyResult("none", false)
    end if
    if context = "menu"
        return rbp_resolveMenuKey(key)
    end if
    if context = "trickPlay"
        return rbp_resolveTrickPlayKey(key)
    end if
    if context = "buttonRow"
        return rbp_resolveButtonRowKey(key)
    end if
    return rbp_resolvePlayerKey(key, overlayVisible, menusEnabled, buttonRowAvailable)
end function

function rbp_resolvePlayerKey(key as string, overlayVisible as boolean, menusEnabled = true as boolean, buttonRowAvailable = true as boolean) as object
    ' Any key wakes a hidden overlay and does nothing else. Otherwise a
    ' user reaching for the remote to see where they are would skip or
    ' pause by accident.
    if not overlayVisible
        if key = "back" then
            return rbp_keyResult("exit", false)
        end if
        return rbp_keyResult("showOverlay", true)
    end if
    if key = "OK" or key = "play" then
        return rbp_keyResult("togglePlayPause", true)
    end if
    if key = "left" then
        return rbp_keyResult("skipBack", true)
    end if
    if key = "right" then
        return rbp_keyResult("skipForward", true)
    end if
    if key = "rewind" then
        return rbp_keyResult("trickRewind", true)
    end if
    if key = "fastforward" then
        return rbp_keyResult("trickForward", true)
    end if
    ' `options` is the * key. On Roku that is the conventional place for
    ' contextual settings, and Roku's own player uses it for audio and
    ' subtitle selection - so the menu goes there rather than on up/down.
    '
    ' It also costs the client nothing they had: up and down stay theirs,
    ' which they would not have if the menu had taken them.
    if key = "options"
        if menusEnabled then
            return rbp_keyResult("openMenu", true)
        end if
        return rbp_keyResult("none", false)
    end if
    ' down moves onto the button row beneath the bar - the gesture every
    ' TV player uses to reach its on-screen controls. With nothing in that
    ' row there is nowhere to go, so down bubbles to the client instead.
    if key = "down"
        if buttonRowAvailable then
            return rbp_keyResult("focusButtonRow", true)
        end if
        return rbp_keyResult("none", false)
    end if
    ' First back hides the overlay; a second one is not ours to handle,
    ' so it bubbles and the channel exits normally.
    if key = "back" then
        return rbp_keyResult("hideOverlay", true)
    end if
    ' up, and anything else, BUBBLES rather than being swallowed:
    ' consuming a key that does nothing steals it from the client for no
    ' benefit, and leaves them with a dead button they cannot diagnose.
    return rbp_keyResult("none", false)
end function

' While the menu is open it owns the screen. Playback keeps running
' underneath - this is a menu over live video, not a modal that pauses -
' but nothing except navigation reaches the player.
function rbp_resolveMenuKey(key as string) as object
    if key = "up" then
        return rbp_keyResult("menuUp", true)
    end if
    if key = "down" then
        return rbp_keyResult("menuDown", true)
    end if
    ' SPATIAL: audio is the left column, subtitles the right. Pressing
    ' left while already in audio does nothing, which is what a sighted
    ' user expects from a key that points at where they already are.
    if key = "left" then
        return rbp_keyResult("menuLeft", true)
    end if
    if key = "right" then
        return rbp_keyResult("menuRight", true)
    end if
    if key = "OK" then
        return rbp_keyResult("menuSelect", true)
    end if
    ' back closes it, and so does another press of the key that opened
    ' it. Both are things people try, and neither should exit the channel.
    if key = "back" or key = "options" then
        return rbp_keyResult("menuClose", true)
    end if
    ' Everything else is swallowed. A stray `play` reaching the player
    ' while the user is reading a subtitle list is exactly the kind of
    ' accident the trickPlay context already guards against.
    return rbp_keyResult("none", true)
end function

' Focus is on the button row under the bar.
'
' The DEDICATED transport keys keep working from here - play, rewind and
' fastforward have one meaning printed on them, and a player that ignores
' the play key because focus happens to be on a button feels broken.
' Only the keys whose meaning depends on position change: left and right
' walk the row, and OK activates whatever is highlighted.
function rbp_resolveButtonRowKey(key as string) as object
    if key = "up" then
        return rbp_keyResult("focusTransport", true)
    end if
    if key = "left" then
        return rbp_keyResult("buttonLeft", true)
    end if
    if key = "right" then
        return rbp_keyResult("buttonRight", true)
    end if
    if key = "OK" then
        return rbp_keyResult("activateButton", true)
    end if
    if key = "options" then
        return rbp_keyResult("openMenu", true)
    end if
    if key = "play" then
        return rbp_keyResult("togglePlayPause", true)
    end if
    if key = "rewind" then
        return rbp_keyResult("trickRewind", true)
    end if
    if key = "fastforward" then
        return rbp_keyResult("trickForward", true)
    end if
    ' back steps focus up rather than hiding everything: the least
    ' destructive thing available, the same rule back follows everywhere.
    if key = "back" then
        return rbp_keyResult("focusTransport", true)
    end if
    ' down is held: this is the bottom row, and letting it bubble would
    ' hand the client a key press while focus is visibly inside the SDK.
    if key = "down" then
        return rbp_keyResult("none", true)
    end if
    return rbp_keyResult("none", false)
end function

function rbp_resolveTrickPlayKey(key as string) as object
    if key = "rewind" then
        return rbp_keyResult("trickRewind", true)
    end if
    if key = "fastforward" then
        return rbp_keyResult("trickForward", true)
    end if
    if key = "OK" or key = "play" then
        return rbp_keyResult("trickCommit", true)
    end if
    if key = "back" then
        return rbp_keyResult("trickCancel", true)
    end if
    ' Everything else is swallowed while scanning. Letting a stray key
    ' through here is how a player ends up seeking somewhere the user
    ' never asked for.
    return rbp_keyResult("none", true)
end function

function rbp_keyResult(action as string, handled as boolean) as object
    return {
        action: action
        handled: handled
    }
end function
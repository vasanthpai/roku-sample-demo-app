'import "pkg:/source/rbp/rbpUtils.bs"
' ======================================================================
' KEY ROUTING
'
' One pure function decides what every key means, given the context the
' player is in. No component ever holds SceneGraph focus, and no node
' handles keys for itself.
'
' Why centralised:
'
'   - it is a table, so every key in every context is a spec
'   - nothing inside the player can steal focus from the client's own UI
'   - P9's menus become a new context, not a re-plumbing exercise
'
' Why no focus ring in the base player: on Roku, left/right in a player
' scrub. If a focusable scrubber captured them, there would be no way to
' leave it. Controls here are keys, not widgets. Focus becomes real in
' P9, where a menu genuinely has a highlighted row.
' ======================================================================

' Actions the caller carries out. Named for intent, not for the key that
' produced them, so the table can be re-bound without touching the player.


' Resolve a key press.
'
' Returns { action, handled }. `handled` tells the caller whether to
' consume the key: returning false lets it bubble, which is how `back`
' eventually exits the channel instead of trapping the user.
function rbp_resolveKey(context as dynamic, key as dynamic, overlayVisible as boolean) as object
    if not rbp_isNonEmptyString(key) then
        return rbp_keyResult("none", false)
    end if
    if context = "trickPlay"
        return rbp_resolveTrickPlayKey(key)
    end if
    return rbp_resolvePlayerKey(key, overlayVisible)
end function

function rbp_resolvePlayerKey(key as string, overlayVisible as boolean) as object
    ' Any key wakes a hidden overlay and does nothing else. Otherwise a
    ' user reaching for the remote to see where they are would skip or
    ' pause by accident.
    if not overlayVisible
        if key = "back" then
            return rbp_keyResult("exit", false)
        end if
        return rbp_keyResult("showOverlay", true)
    end if
    if key = "OK" or key = "play" then
        return rbp_keyResult("togglePlayPause", true)
    end if
    if key = "left" then
        return rbp_keyResult("skipBack", true)
    end if
    if key = "right" then
        return rbp_keyResult("skipForward", true)
    end if
    if key = "rewind" then
        return rbp_keyResult("trickRewind", true)
    end if
    if key = "fastforward" then
        return rbp_keyResult("trickForward", true)
    end if
    ' First back hides the overlay; a second one is not ours to handle,
    ' so it bubbles and the channel exits normally.
    if key = "back" then
        return rbp_keyResult("hideOverlay", true)
    end if
    ' up and down will open menus in P9. Until then they BUBBLE rather
    ' than being swallowed: consuming a key that does nothing steals it
    ' from the client for no benefit, and leaves them with a dead button
    ' they cannot diagnose.
    return rbp_keyResult("none", false)
end function

function rbp_resolveTrickPlayKey(key as string) as object
    if key = "rewind" then
        return rbp_keyResult("trickRewind", true)
    end if
    if key = "fastforward" then
        return rbp_keyResult("trickForward", true)
    end if
    if key = "OK" or key = "play" then
        return rbp_keyResult("trickCommit", true)
    end if
    if key = "back" then
        return rbp_keyResult("trickCancel", true)
    end if
    ' Everything else is swallowed while scanning. Letting a stray key
    ' through here is how a player ends up seeking somewhere the user
    ' never asked for.
    return rbp_keyResult("none", true)
end function

function rbp_keyResult(action as string, handled as boolean) as object
    return {
        action: action
        handled: handled
    }
end function
'import "pkg:/source/rbp/rbpUtils.bs"
' ======================================================================
' ANALYTICS PAYLOADS
'
' The session already decided WHICH events a transition implies and
' computed their metadata. This file only enriches them with the
' player's state at the moment they fired, and shapes the client-facing
' payload.
'
' Pure functions - no nodes, no clock. The snapshot is passed in.
' ======================================================================

' One event, as a client receives it.
'
'   name       an rbp.PlayerEvent
'   timestamp  epoch seconds - for correlating with a backend
'   sessionMs  ms since load() - precise, and monotonic within a session
'   position   playback position in seconds when the event fired
'   duration   stream duration in seconds, 0 if not yet known
'   state      the rbp.PlayerState the player is in
'   meta       event-specific detail (startupMs, stalledMs, target, ...)
'
' Both clocks are provided on purpose: `timestamp` correlates with other
' systems but has one-second resolution, while `sessionMs` is precise
' enough to order events that happen milliseconds apart.
function rbp_toAnalyticsPayload(evt as object, snapshot as object) as object
    meta = evt.meta
    if meta = invalid then
        meta = {}
    end if
    return {
        name: evt.name
        ' NOT toPositiveInt - both of these exceed the range where
        ' BrightScript's float-backed int() stays exact. Epoch seconds
        ' are ~1.7e9; sessionMs passes 2^24 after ~4.6 hours of playback.
        timestamp: rbp_toSafeNumber(snapshot.timestamp)
        sessionMs: rbp_toSafeNumber(evt.atMs)
        position: rbp_toPositiveInt(snapshot.position)
        duration: rbp_toPositiveInt(snapshot.duration)
        state: snapshot.state
        meta: meta
    }
end function

' All events from a single transition, delivered as one notification.
'
' SceneGraph coalesces rapid writes to a field, and one transition can
' produce two events - bufferEnd plus seekEnd, for instance. Setting the
' field once per event would risk the client's observer only ever seeing
' the last one, and analytics that silently drops events is worse than an
' API that hands over a short list.
'
' `sequence` increments per batch so a client can detect a missed
' notification rather than quietly under-reporting.
function rbp_toAnalyticsBatch(events as object, snapshot as object, sequence as integer) as object
    payloads = []
    if events <> invalid
        for each evt in events
            payloads.push(rbp_toAnalyticsPayload(evt, snapshot))
        end for
    end if
    return {
        sequence: sequence
        events: payloads
    }
end function
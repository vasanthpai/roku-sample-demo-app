' Type guards. BrightScript has no exceptions - an unhandled error kills
' the whole channel, including the client's app. So every value crossing
' the public boundary is checked before it is used.
function rbp_isNonEmptyString(value as dynamic) as boolean
    if value = invalid then
        return false
    end if
    t = type(value)
    if t <> "String" and t <> "roString" then
        return false
    end if
    return len(value) > 0
end function

function rbp_isAA(value as dynamic) as boolean
    if value = invalid then
        return false
    end if
    return type(value) = "roAssociativeArray"
end function

function rbp_endsWith(value as string, suffix as string) as boolean
    if len(suffix) > len(value) then
        return false
    end if
    return right(value, len(suffix)) = suffix
end function

' Coerce a value to a positive integer, or 0.
'
' BrightScript boxes numbers stored in associative arrays, so type() can
' return "roInt" where you expect "Integer" - and a float is a legitimate
' duration too. Checking one type name silently discards valid input, so
' every numeric type is accepted and anything else becomes 0.
function rbp_toPositiveInt(value as dynamic) as integer
    if not rbp_isNumeric(value) then
        return 0
    end if
    n = int(value)
    if n > 0 then
        return n
    end if
    return 0
end function

' Numeric type check that tolerates boxing. See toPositiveInt.
function rbp_isNumeric(value as dynamic) as boolean
    if value = invalid then
        return false
    end if
    t = type(value)
    return t = "Integer" or t = "roInt" or t = "roInteger" or t = "LongInteger" or t = "roLongInteger" or t = "Float" or t = "roFloat" or t = "Double" or t = "roDouble"
end function
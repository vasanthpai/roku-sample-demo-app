' Type guards. BrightScript has no exceptions - an unhandled error kills
' the whole channel, including the client's app. So every value crossing
' the public boundary is checked before it is used.
function rbp_isNonEmptyString(value as dynamic) as boolean
    if value = invalid then
        return false
    end if
    t = type(value)
    if t <> "String" and t <> "roString" then
        return false
    end if
    return len(value) > 0
end function

function rbp_isAA(value as dynamic) as boolean
    if value = invalid then
        return false
    end if
    return type(value) = "roAssociativeArray"
end function

function rbp_endsWith(value as string, suffix as string) as boolean
    if len(suffix) > len(value) then
        return false
    end if
    return right(value, len(suffix)) = suffix
end function

' Coerce a value to a positive integer, or 0.
'
' BrightScript boxes numbers stored in associative arrays, so type() can
' return "roInt" where you expect "Integer" - and a float is a legitimate
' duration too. Checking one type name silently discards valid input, so
' every numeric type is accepted and anything else becomes 0.
function rbp_toPositiveInt(value as dynamic) as integer
    if not rbp_isNumeric(value) then
        return 0
    end if
    n = int(value)
    if n > 0 then
        return n
    end if
    return 0
end function

' Numeric type check that tolerates boxing. See toPositiveInt.
function rbp_isNumeric(value as dynamic) as boolean
    if value = invalid then
        return false
    end if
    t = type(value)
    return t = "Integer" or t = "roInt" or t = "roInteger" or t = "LongInteger" or t = "roLongInteger" or t = "Float" or t = "roFloat" or t = "Double" or t = "roDouble"
end function

' Large-magnitude numeric pass-through.
'
' BrightScript's int() is float-backed: above ~16.7 million (2^24) it
' rounds to the nearest representable float. At epoch-second magnitudes
' (~1.7 billion) that spacing is 128, so int() turns 1735000000 into
' 1735000064 - a 64-second error on every timestamp.
'
' Values that can exceed 2^24 must be validated and passed through
' untouched, never coerced. Use toPositiveInt only for small numbers
' like positions and durations in seconds.
function rbp_toSafeNumber(value as dynamic) as dynamic
    if not rbp_isNumeric(value) then
        return 0
    end if
    return value
end function

' A value crossing a node boundary can arrive BOXED - "roBoolean" rather
' than "Boolean" - in the same way P1's duration came back as a boxed
' roInt. Checking one spelling would reject a perfectly good value and
' silently reinstate the default.
function rbp_isBoolean(value as dynamic) as boolean
    t = type(value)
    return t = "Boolean" or t = "roBoolean"
end function

' First non-empty string value among several candidate keys.
'
' Roku's track structs use different key names for audio and subtitle
' entries, and those names vary by firmware and stream. Trying a list of
' candidates is more honest than asserting one shape and silently
' producing empty labels when the assumption is wrong.
function rbp_firstStringValue(source as dynamic, keys as object) as string
    if not rbp_isAA(source) then
        return ""
    end if
    for each key in keys
        if source.doesExist(key)
            value = source[key]
            if rbp_isNonEmptyString(value) then
                return value
            end if
        end if
    end for
    return ""
end function
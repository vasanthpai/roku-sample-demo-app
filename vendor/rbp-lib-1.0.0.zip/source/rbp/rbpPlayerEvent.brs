' Analytics event names. Emitted by the dispatcher in P4.
'
' Declared now so the vocabulary is fixed before anything emits it.
' Additive by design: new events never break an existing client handler,
' because clients switch on names they know and ignore the rest.

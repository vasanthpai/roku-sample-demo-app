' Analytics event names, emitted by the dispatcher.
'
' RULE: declare a name only when something emits it. Reserving an event
' the way MediaItem reserves fields is a trap - a client reading the
' catalogue waits forever for an event that never fires. Fields are safe
' to reserve because a client just reads a default; events are not.
'
' Adding events later IS safe: they are name-based, and clients switch on
' the names they know and ignore the rest.
'
' Declared now so the vocabulary is fixed before anything emits it.
' Additive by design: new events never break an existing client handler,
' because clients switch on names they know and ignore the rest.

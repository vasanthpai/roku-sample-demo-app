'import "pkg:/source/rbp/rbpUtils.bs"
'import "pkg:/source/rbp/rbpPlayerState.bs"
' Roku Video node control values. Roku's vocabulary, not ours - kept
' internal and never exposed to clients.


' Decide which control value a requested action maps to.
'
' This exists because `play` and `resume` are NOT interchangeable on Roku:
' sending "play" to a paused video restarts it from the beginning. Getting
' that wrong is a bug a user notices immediately and a test never would,
' unless the decision is pulled out here where it can be asserted.
'
' Returns VideoControl.none for a no-op - pausing an already-paused video
' should not touch the node at all.
'
'   action: "play" | "pause" | "stop"
function rbp_resolveControl(action as dynamic, currentState as dynamic) as string
    if not rbp_isNonEmptyString(action) then
        return ""
    end if
    if not rbp_isNonEmptyString(currentState) then
        currentState = "idle"
    end if
    if action = "play"
        ' Resuming only makes sense from paused. Everything else is a
        ' fresh start - including after stop, ended, or an error.
        if currentState = "paused" then
            return "resume"
        end if
        if currentState = "playing" then
            return ""
        end if
        if currentState = "buffering" then
            return ""
        end if
        ' A seek is already in flight - playback resumes on its own, and
        ' sending "play" here would restart the stream from zero.
        if currentState = "seeking" then
            return ""
        end if
        return "play"
    end if
    if action = "pause"
        if currentState = "playing" then
            return "pause"
        end if
        if currentState = "buffering" then
            return "pause"
        end if
        if currentState = "seeking" then
            return "pause"
        end if
        return ""
    end if
    if action = "stop"
        if currentState = "idle" then
            return ""
        end if
        return "stop"
    end if
    return ""
end function

' Decide the real seek target for a requested position.
'
' Seeking before a stream is ready fails silently on Roku - no error, no
' event, nothing happens. So readiness is checked rather than attempted.
'
' Returns { ok, position, reason }.
function rbp_resolveSeek(requested as dynamic, duration as dynamic, isReady as boolean) as object
    if not isReady
        return {
            ok: false
            position: 0
            reason: "notReady"
        }
    end if
    if not rbp_isNumeric(requested)
        return {
            ok: false
            position: 0
            reason: "invalidPosition"
        }
    end if
    target = int(requested)
    if target < 0 then
        target = 0
    end if
    ' Clamp short of the end. Seeking exactly to duration ends playback
    ' immediately, which is never what someone scrubbing to the end wants.
    limit = rbp_toPositiveInt(duration)
    if limit > 0 and target > limit - 1
        target = limit - 1
        if target < 0 then
            target = 0
        end if
    end if
    return {
        ok: true
        position: target
        reason: ""
    }
end function
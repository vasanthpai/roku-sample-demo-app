' The client-facing contract. This is the shape a client constructs in
' their own code and hands to load().
'
' This is the most expensive artifact in P1: once clients integrate
' against it, changing a field breaks their apps. Adding one is safe -
' old clients omit it and get the default. That asymmetry is why the
' reserved fields below exist before anything reads them.
'
'   REQUIRED   url
'   RESOLVED   format - supplied, or inferred from the url extension
'   OPTIONAL   id, title, description, artwork, duration, ageRating
'              id is used for analytics correlation; empty is allowed
'   RESERVED   isLive, drm, startPosition, adConfig
'
' Unknown keys are passed through untouched, so a client can carry their
' own metadata on the item without the SDK stripping it.
function rbp_newMediaItem(source = invalid as object) as object
    item = {
        id: ""
        title: ""
        url: ""
        format: ""
        description: ""
        artwork: ""
        duration: 0
        ageRating: ""
        ' Reserved. Declared with inert defaults so that adding these
        ' features later fills in a field rather than changing a schema
        ' clients already depend on. Nothing reads them yet.
        isLive: false
        drm: invalid
        startPosition: 0
        adConfig: invalid
    }
    if source <> invalid and type(source) = "roAssociativeArray"
        for each key in source
            item[key] = source[key]
        end for
    end if
    return item
end function
' Roku Video node "state" -> SDK PlayerState.
'
' DATA ONLY. No history, no conditionals, no side effects.
'
' Roku reports "buffering" for BOTH the initial buffer and a mid-playback
' rebuffer. Telling those apart needs session history ("has this session
' ever reached playing?"), which is the state machine's job in P3. Keeping
' this table dumb means P3 adds that logic without touching the mapping.
function rbp_rawStateMap() as object
    return {
        "none": "idle"
        "buffering": "buffering"
        "playing": "playing"
        "paused": "paused"
        "stopped": "idle"
        "finished": "ended"
        "error": "error"
    }
end function

' Unknown or missing input resolves to idle - an inert value that cannot
' mislead a client. P3 logs unknowns so a firmware change surfaces.
function rbp_mapRawState(rawState as dynamic) as string
    if rawState = invalid then
        return "idle"
    end if
    if type(rawState) <> "String" and type(rawState) <> "roString"
        return "idle"
    end if
    map = rbp_rawStateMap()
    if map.doesExist(rawState) then
        return map[rawState]
    end if
    return "idle"
end function

function rbp_isKnownRawState(rawState as dynamic) as boolean
    if rawState = invalid then
        return false
    end if
    return rbp_rawStateMap().doesExist(rawState)
end function
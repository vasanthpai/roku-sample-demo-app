'import "pkg:/source/rbp/rbpPlayerState.bs"
'import "pkg:/source/rbp/rbpPlayerEvent.bs"
'import "pkg:/source/rbp/rbpStateMap.bs"
'import "pkg:/source/rbp/rbpUtils.bs"
' ======================================================================
' SESSION CONTEXT
'
' Everything P2 could not answer comes down to the player having no
' memory. This is that memory - nine fields, reset on every load().
'
' Every function below is pure: context in, new context out, plus the
' events the transition implies. Nothing here touches a node or reads a
' clock, which is why the whole state machine is testable off-device.
' ======================================================================
function rbp_newSession(nowMs as integer) as object
    return {
        state: "idle"
        ' Disambiguates Roku's single "buffering" state: has this session
        ' ever reached playing? If not, we are still starting up.
        hasPlayed: false
        seekPending: false
        seekTarget: 0
        ' Timing, consumed by diagnostics in P11.
        startedAtMs: nowMs
        firstPlayAtMs: 0
        rebufferCount: 0
        rebufferStartedAtMs: 0
        rebufferMs: 0
        ' Why the current buffering started. A track switch makes Roku
        ' rebuffer, but that is the user's own doing - counting it as a
        ' stall would make stream quality look worse than it is.
        bufferCause: ""
        trackChangePending: false
        ' Guard bookkeeping - a rising count means Roku is reporting
        ' transitions we do not model.
        droppedCount: 0
    }
end function

' A new media item starts a new session. Everything resets.
function rbp_sessionOnLoad(ctx as object, nowMs as integer) as object
    fresh = rbp_newSession(nowMs)
    ' loadStart and loadComplete bracket validation and content
    ' assignment. The gap to playbackStart is network and decode time,
    ' which is what makes startup latency attributable.
    return {
        ctx: fresh
        events: [
            rbp_sessionEvent("loadStart", nowMs, {})
            rbp_sessionEvent("loadComplete", nowMs, {})
        ]
    }
end function

' ======================================================================
' THE TRANSITION
'
' Raw Roku state in, SDK state out, plus the events it implies. P4's
' dispatcher is a loop over that event list - the thinking happens here.
' ======================================================================
function rbp_sessionOnRawState(ctx as object, rawState as dynamic, nowMs as integer) as object
    nextState = rbp_mapRawState(rawState)
    events = []
    ' A seek is in flight until playback resumes, whatever Roku reports
    ' in between. Without this the state flickers seeking -> buffering ->
    ' seeking as the stream re-establishes.
    if ctx.seekPending and nextState <> "playing" and nextState <> "error"
        return {
            ctx: ctx
            events: events
        }
    end if
    ' Same state carries no information. It is a no-op, NOT a sign that
    ' Roku reported something we failed to model - so it must not touch
    ' droppedCount, or that counter loses its meaning as a signal.
    if nextState = ctx.state
        return {
            ctx: ctx
            events: events
        }
    end if
    if not rbp_isLegalTransition(ctx.state, nextState)
        out = rbp_copySession(ctx)
        out.droppedCount = ctx.droppedCount + 1
        return {
            ctx: out
            events: events
        }
    end if
    out = rbp_copySession(ctx)
    out.state = nextState
    if nextState = "buffering"
        ' THE DISAMBIGUATION. Roku reports "buffering" for both the
        ' initial buffer and a mid-playback stall. hasPlayed is the only
        ' reliable discriminator.
        out.rebufferStartedAtMs = nowMs
        if not ctx.hasPlayed
            out.bufferCause = "startup"
            events.push(rbp_sessionEvent("bufferStart", nowMs, {
                initial: true
                cause: "startup"
            }))
        else if ctx.trackChangePending
            ' The user just switched track. Roku rebuffers to fetch the
            ' new rendition - expected, and not a quality problem.
            out.trackChangePending = false
            out.bufferCause = "trackChange"
            events.push(rbp_sessionEvent("bufferStart", nowMs, {
                initial: false
                cause: "trackChange"
            }))
        else
            out.bufferCause = "stall"
            out.rebufferCount = ctx.rebufferCount + 1
            events.push(rbp_sessionEvent("bufferStart", nowMs, {
                initial: false
                cause: "stall"
            }))
        end if
    else if nextState = "playing"
        if not ctx.hasPlayed
            out.hasPlayed = true
            out.firstPlayAtMs = nowMs
            ' Startup time: load() to first frame. P11 reports this.
            events.push(rbp_sessionEvent("playbackStart", nowMs, {
                startupMs: nowMs - ctx.startedAtMs
            }))
        else if ctx.state = "buffering" and ctx.rebufferStartedAtMs > 0
            stalled = nowMs - ctx.rebufferStartedAtMs
            ' Only a genuine stall counts toward stalled time. The event
            ' still carries the duration either way, so a client can see
            ' what a track switch cost without it polluting the metric.
            if ctx.bufferCause = "stall" then
                out.rebufferMs = ctx.rebufferMs + stalled
            end if
            out.rebufferStartedAtMs = 0
            out.bufferCause = ""
            events.push(rbp_sessionEvent("bufferEnd", nowMs, {
                stalledMs: stalled
                cause: ctx.bufferCause
            }))
        else if ctx.state = "paused"
            events.push(rbp_sessionEvent("play", nowMs, {}))
        end if
        if ctx.seekPending
            out.seekPending = false
            events.push(rbp_sessionEvent("seekEnd", nowMs, {
                target: ctx.seekTarget
            }))
        end if
    else if nextState = "paused"
        events.push(rbp_sessionEvent("pause", nowMs, {}))
    else if nextState = "ended"
        events.push(rbp_sessionEvent("ended", nowMs, {}))
    else if nextState = "idle"
        ' Without an event here a client cannot tell a deliberate stop
        ' from nothing happening. But only if playback was actually
        ' abandoned: Roku reports idle after a stream finishes too, and
        ' emitting stopped there would count every completed view as an
        ' abandonment.
        if ctx.hasPlayed and ctx.state <> "ended"
            events.push(rbp_sessionEvent("stopped", nowMs, {}))
        end if
    else if nextState = "error"
        out.seekPending = false
        events.push(rbp_sessionEvent("error", nowMs, {}))
    end if
    return {
        ctx: out
        events: events
    }
end function

' ======================================================================
' SEEK
'
' P2 showed that hammering seek queues wasted work - each one triggers a
' full buffering cycle. One seek is in flight at a time.
' ======================================================================
function rbp_sessionOnSeek(ctx as object, target as integer, nowMs as integer) as object
    if ctx.seekPending
        return {
            ctx: ctx
            events: []
            accepted: false
            reason: "seekInFlight"
        }
    end if
    out = rbp_copySession(ctx)
    out.seekPending = true
    out.seekTarget = target
    out.state = "seeking"
    return {
        ctx: out
        events: [
            rbp_sessionEvent("seekStart", nowMs, {
                target: target
            })
        ]
        accepted: true
        reason: ""
    }
end function

' A track selection is not a state transition - the context is unchanged.
' It still routes through here so that every event the client receives
' travels the same path, rather than analytics having two sources that
' can drift apart.
function rbp_sessionOnTrackChange(ctx as object, kind as string, trackId as string, nowMs as integer) as object
    out = rbp_copySession(ctx)
    ' Roku rebuffers to fetch the new rendition. Flagging it here lets the
    ' next buffering transition tell a user-initiated switch apart from a
    ' network stall.
    out.trackChangePending = true
    return {
        ctx: out
        events: [
            rbp_sessionEvent("trackChange", nowMs, {
                kind: kind
                trackId: trackId
            })
        ]
    }
end function

' Position is provisional while a seek is in flight. Roku reports the
' requested position, then buffers, then corrects to the segment boundary
' it actually landed on - so a scrubber that trusts it jumps backwards.
function rbp_acceptsPosition(ctx as object) as boolean
    return not ctx.seekPending
end function

' ======================================================================
' GUARDS
'
' Deliberately a deny-list, not an allow-list. We cannot enumerate every
' transition Roku might legitimately report across firmware versions, so
' unknown ones pass through and only the provably wrong are dropped.
' A rising droppedCount is the signal to revisit this.
' ======================================================================
function rbp_isLegalTransition(fromState as string, toState as string) as boolean
    ' Same state is not an error, but it carries no information and would
    ' emit duplicate events.
    if fromState = toState then
        return false
    end if
    ' Nothing is loaded, so there is nothing to pause or resume.
    if fromState = "idle" and toState = "paused" then
        return false
    end if
    ' Once a session has errored it is over. Roku reports "finished"
    ' immediately after a failed load, and passing that through would
    ' emit `ended` - telling a client's analytics the content played to
    ' completion when in fact it never started.
    if fromState = "error" and toState = "ended" then
        return false
    end if
    return true
end function

' ======================================================================
' INTERNAL
' ======================================================================
function rbp_sessionEvent(name as string, atMs as integer, meta as object) as object
    return {
        name: name
        atMs: atMs
        meta: meta
    }
end function

' Explicit copy - these functions must never mutate the context they are
' given, or the caller cannot compare before and after.
function rbp_copySession(ctx as object) as object
    return {
        state: ctx.state
        hasPlayed: ctx.hasPlayed
        seekPending: ctx.seekPending
        seekTarget: ctx.seekTarget
        startedAtMs: ctx.startedAtMs
        firstPlayAtMs: ctx.firstPlayAtMs
        rebufferCount: ctx.rebufferCount
        rebufferStartedAtMs: ctx.rebufferStartedAtMs
        rebufferMs: ctx.rebufferMs
        bufferCause: ctx.bufferCause
        trackChangePending: ctx.trackChangePending
        droppedCount: ctx.droppedCount
    }
end function

' Position throttling. Roku fires position on a timer, not on change, and
' clients rarely want every tick. Pure, so the interval logic is testable
' without waiting for real time to pass.
function rbp_shouldEmitPosition(lastEmittedMs as integer, nowMs as integer, intervalMs as integer) as boolean
    if intervalMs <= 0 then
        return true
    end if
    if lastEmittedMs <= 0 then
        return true
    end if
    return (nowMs - lastEmittedMs) >= intervalMs
end function
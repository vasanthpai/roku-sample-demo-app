'import "pkg:/source/rbp/rbpUtils.bs"
' ======================================================================
' FORMATTING
'
' Pure. Seconds in, display strings out.
' ======================================================================

' Seconds to a clock string.
'
'   45      -> "0:45"
'   605     -> "10:05"
'   3661    -> "1:01:01"
'
' The hour field only appears when there is one, so a short clip does not
' read "0:00:45". Minutes are padded only when hours are shown, matching
' how every other player on the platform renders it.
function rbp_formatTime(totalSeconds as dynamic) as string
    seconds = rbp_toPositiveInt(totalSeconds)
    hours = int(seconds / 3600)
    minutes = int((seconds - hours * 3600) / 60)
    secs = seconds - hours * 3600 - minutes * 60
    if hours > 0
        return Str(hours).trim() + ":" + rbp_pad2(minutes) + ":" + rbp_pad2(secs)
    end if
    return Str(minutes).trim() + ":" + rbp_pad2(secs)
end function

' Remaining time, as players conventionally show it.
'
'   "-2:15"
'
' Returns "" when the duration is unknown, rather than a misleading
' "-0:00" that would read as "about to end".
function rbp_formatRemaining(position as dynamic, duration as dynamic) as string
    total = rbp_toPositiveInt(duration)
    if total <= 0 then
        return ""
    end if
    remaining = total - rbp_toPositiveInt(position)
    if remaining < 0 then
        remaining = 0
    end if
    return "-" + rbp_formatTime(remaining)
end function

' Trick-play speed, for the on-screen indicator.
'
'   +1, 8   -> "8x"
'   -1, 8   -> "-8x"
function rbp_formatSpeed(direction as integer, speed as integer) as string
    if speed <= 0 then
        return ""
    end if
    if direction < 0 then
        return "-" + Str(speed).trim() + "x"
    end if
    return Str(speed).trim() + "x"
end function

function rbp_pad2(value as integer) as string
    if value < 10 then
        return "0" + Str(value).trim()
    end if
    return Str(value).trim()
end function
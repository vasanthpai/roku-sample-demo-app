'import "pkg:/source/rbp/rbpUtils.bs"
'import "pkg:/source/rbp/rbpPlayerState.bs"
' ======================================================================
' OVERLAY VISIBILITY
'
' Pure. The caller supplies the clock, so a five second timeout is
' asserted in a test without waiting five seconds.
' ======================================================================
function rbp_newOverlay(nowMs as integer) as object
    return {
        visible: true ' shown on load, so the user sees what started
        lastInteractionMs: nowMs
    }
end function

' Should the overlay still be on screen?
'
' It hides only while playback is actually running. Paused, buffering,
' ended or errored, it stays put: a player that hides its controls while
' paused leaves the user staring at a still frame with no way to tell
' whether anything is wrong.
function rbp_overlayShouldShow(state as object, playerState as dynamic, nowMs as integer, hideAfterMs as integer) as boolean
    if not state.visible then
        return false
    end if
    if hideAfterMs <= 0 then
        return true
    end if
    if playerState <> "playing" then
        return true
    end if
    return (nowMs - state.lastInteractionMs) < hideAfterMs
end function

' Any interaction resets the countdown and brings the overlay back.
function rbp_overlayOnInteraction(state as object, nowMs as integer) as object
    return {
        visible: true
        lastInteractionMs: nowMs
    }
end function

function rbp_overlayHide(state as object, nowMs as integer) as object
    return {
        visible: false
        lastInteractionMs: nowMs
    }
end function

' ======================================================================
' RATING BUG
'
' The age rating shown top-left for the first few seconds of playback,
' the way broadcast television does it.
'
' Driven by POSITION, not by a timer. Position is already pushed to the
' overlay, so this needs no clock and no extra state - and it behaves
' correctly for free on the cases a timer gets wrong: it does not burn
' down while paused, and it does not keep counting while the user is
' scanning through the opening.
'
' It is deliberately independent of the controls overlay. The rating is a
' compliance marker, not a control, so it must not disappear because the
' controls timed out.
function rbp_shouldShowRatingBug(hasRating as boolean, enabled as boolean, position as dynamic, bugSeconds as dynamic) as boolean
    if not hasRating then
        return false
    end if
    if not enabled then
        return false
    end if
    ' 0 means "for the whole stream" - some ratings boards require the
    ' marker to stay up permanently.
    seconds = rbp_toSafeNumber(bugSeconds)
    if seconds <= 0 then
        return true
    end if
    return rbp_toSafeNumber(position) < seconds
end function

' ======================================================================
' CENTRED ROW
'
' x of the first item in a horizontally centred row. The icon row uses
' it, and it stays correct when a client changes iconSize or gap, which
' a hard-coded offset would not.
' ======================================================================
function rbp_centeredRowStart(count as dynamic, itemSize as dynamic, gap as dynamic, containerWidth as dynamic) as integer
    n = rbp_toPositiveInt(count)
    if n <= 0 then
        return 0
    end if
    item = rbp_toPositiveInt(itemSize)
    spacing = rbp_toPositiveInt(gap)
    width = rbp_toPositiveInt(containerWidth)
    rowWidth = n * item + (n - 1) * spacing
    start = int((width - rowWidth) / 2)
    ' A row wider than its container is pinned left rather than pushed
    ' off the near edge, which is the more recoverable failure.
    if start < 0 then
        return 0
    end if
    return start
end function
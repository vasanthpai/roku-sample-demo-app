'import "pkg:/source/rbp/rbpUtils.bs"
'import "pkg:/source/rbp/rbpMediaItem.bs"
'import "pkg:/source/rbp/rbpValidation.bs"
' MediaItem -> a plain description of a ContentNode.
'
' PURE FUNCTION. Takes an AA, returns an AA. It creates no nodes, touches
' no `m.`, reads no globals, and needs no device.
'
' That constraint is the whole point: a real ContentNode only exists on a
' Roku, so a mapper that built one could only be tested by deploying and
' reading a console. Returning a description instead means every edge case
' is asserted instantly in Rooibos. A thin wrapper in P2 turns this into an
' actual node, and that wrapper is too small to hide a bug.
function rbp_mapToContent(item as object) as object
    content = {
        url: item.url
        streamFormat: item.format
        title: ""
        description: ""
        hdPosterUrl: ""
        length: 0
        rating: ""
    }
    if rbp_isNonEmptyString(item.title) then
        content.title = item.title
    end if
    if rbp_isNonEmptyString(item.description) then
        content.description = item.description
    end if
    if rbp_isNonEmptyString(item.artwork) then
        content.hdPosterUrl = item.artwork
    end if
    if rbp_isNonEmptyString(item.ageRating) then
        content.rating = item.ageRating
    end if
    content.length = rbp_toPositiveInt(item.duration)
    ' isLive / drm / startPosition / adConfig are reserved and not mapped.
    ' They land here when their phases arrive.
    return content
end function

' The single entry point load() uses: validate, normalise, map.
'
' Returns { ok, code, message, item, content }.
' On failure item and content are invalid and code says why.
function rbp_buildContent(source as dynamic) as object
    result = rbp_validateMediaItem(source)
    if not result.ok
        return {
            ok: false
            code: result.code
            message: result.message
            item: invalid
            content: invalid
        }
    end if
    item = rbp_newMediaItem(source)
    item.format = result.format
    return {
        ok: true
        code: "none"
        message: ""
        item: item
        content: rbp_mapToContent(item)
    }
end function
'import "pkg:/source/rbp/rbpMenu.bs"
'import "pkg:/source/rbp/rbpTrack.bs"
'import "pkg:/source/rbp/rbpUtils.bs"

sub init()
    m.systemFontUri = invalid
    m.visibleCount = 0
    m.audioNodes = []
    m.subtitleNodes = []
    m.dim = m.top.findNode("dim")
    m.title = m.top.findNode("title")
    m.hint = m.top.findNode("hint")
    m.audioColumn = m.top.findNode("audioColumn")
    m.audioHead = m.top.findNode("audioHead")
    m.audioRule = m.top.findNode("audioRule")
    m.audioRowsGroup = m.top.findNode("audioRowsGroup")
    m.audioMore = m.top.findNode("audioMore")
    m.subtitleColumn = m.top.findNode("subtitleColumn")
    m.subtitleHead = m.top.findNode("subtitleHead")
    m.subtitleRule = m.top.findNode("subtitleRule")
    m.subtitleRowsGroup = m.top.findNode("subtitleRowsGroup")
    m.subtitleMore = m.top.findNode("subtitleMore")
    m.title.text = "Audio & Subtitles"
    m.audioHead.text = "Audio"
    m.subtitleHead.text = "Subtitles"
    m.hint.text = "LEFT / RIGHT  switch      OK  select      BACK  close"
    m.top.observeField("theme", "onThemeChanged")
    m.top.observeField("size", "onSizeChanged")
    m.top.observeField("audioRows", "render")
    m.top.observeField("subtitleRows", "render")
    m.top.observeField("kind", "render")
    m.top.observeField("index", "render")
end sub

sub onSizeChanged()
    applyLayout()
    render()
end sub

sub onThemeChanged()
    theme = m.top.theme
    if not rbp_isAA(theme) or not rbp_isAA(theme.colors) then
        return
    end if
    colors = theme.colors
    fonts = theme.fonts
    ' Darker than the controls scrim. The controls sit over a playing frame
    ' the user is still watching; this panel replaces them, and the lists are
    ' the only thing being read while it is up.
    m.dim.color = withAlpha(colors.background, "E6")
    m.title.color = colors.text
    setFont(m.title, fonts, fonts.titleSize, true)
    for each head in [
        m.audioHead
        m.subtitleHead
    ]
        setFont(head, fonts, fonts.bodySize, true)
    end for
    for each more in [
        m.audioMore
        m.subtitleMore
    ]
        more.color = colors.textMuted
        setFont(more, fonts, fonts.captionSize)
    end for
    m.hint.color = colors.textMuted
    setFont(m.hint, fonts, fonts.captionSize)
    ' Row fonts are set as the nodes are built, so a theme change has to
    ' rebuild them to take effect.
    m.audioNodes = []
    m.subtitleNodes = []
    applyLayout()
    render()
end sub

' A theme colour at a different opacity. Colours reach here already
' normalised to 0xRRGGBBAA by rbp.resolveTheme(), so the alpha is always the
' last two characters.
function withAlpha(color as string, alpha as string) as string
    if len(color) <> 10 then
        return color
    end if
    return left(color, 8) + alpha
end function

' ==========================================================================
' LAYOUT
'
' The panel owns the whole frame while it is open - the controls are hidden
' underneath it - so the columns can use the full safe area. How many rows
' fit falls out of that space rather than being a constant, so a client
' raising bodySize gets fewer, larger rows instead of a clipped list.
' ==========================================================================
sub applyLayout()
    theme = m.top.theme
    if not rbp_isAA(theme) or not rbp_isAA(theme.sizes) then
        return
    end if
    size = m.top.size
    if size = invalid then
        return
    end if
    w = size[0]
    h = size[1]
    gap = rbp_toPositiveInt(theme.spacing.gap)
    pad = rbp_toPositiveInt(theme.spacing.barPadding)
    titleSize = rbp_toPositiveInt(theme.fonts.titleSize)
    bodySize = rbp_toPositiveInt(theme.fonts.bodySize)
    captionSize = rbp_toPositiveInt(theme.fonts.captionSize)
    safeInset = int(h * 0.05)
    m.rowHeight = bodySize + gap
    m.gap = gap
    m.dim.width = w
    m.dim.height = h
    ' Content is centred and capped, so on a very wide canvas the two
    ' columns stay close enough to read as one panel.
    contentWidth = w - pad * 4
    if contentWidth > 960 then
        contentWidth = 960
    end if
    contentX = int((w - contentWidth) / 2)
    columnGap = gap * 3
    m.columnWidth = int((contentWidth - columnGap) / 2)
    titleTop = safeInset + gap
    m.title.translation = [
        contentX
        titleTop
    ]
    columnTop = titleTop + titleSize + gap * 2
    m.audioColumn.translation = [
        contentX
        columnTop
    ]
    m.subtitleColumn.translation = [
        contentX + m.columnWidth + columnGap
        columnTop
    ]
    headHeight = bodySize + int(gap / 2)
    ruleTop = headHeight
    rowsTop = ruleTop + 2 + int(gap / 2)
    hintTop = h - safeInset - captionSize
    moreHeight = captionSize + int(gap / 2)
    rowsBottom = (hintTop - gap) - columnTop - moreHeight
    m.visibleCount = int((rowsBottom - rowsTop) / m.rowHeight)
    if m.visibleCount < 1 then
        m.visibleCount = 1
    end if
    for each pair in [
        [
            m.audioHead
            m.audioRule
            m.audioRowsGroup
            m.audioMore
        ]
        [
            m.subtitleHead
            m.subtitleRule
            m.subtitleRowsGroup
            m.subtitleMore
        ]
    ]
        pair[0].translation = [
            0
            0
        ]
        pair[1].translation = [
            0
            ruleTop
        ]
        pair[1].width = m.columnWidth
        pair[1].height = 2
        pair[2].translation = [
            0
            rowsTop
        ]
        pair[3].translation = [
            0
            rowsTop + m.visibleCount * m.rowHeight + int(gap / 4)
        ]
        pair[3].width = m.columnWidth
        pair[3].horizAlign = "right"
    end for
    m.hint.translation = [
        contentX
        hintTop
    ]
    m.hint.width = contentWidth
    m.audioNodes = buildRows(m.audioRowsGroup, m.audioNodes)
    m.subtitleNodes = buildRows(m.subtitleRowsGroup, m.subtitleNodes)
end sub

' Exactly as many row nodes as fit, created once and reused. Rebuilding on
' every render would churn the scene graph on each key press.
function buildRows(group as object, existing as object) as object
    if existing.count() = m.visibleCount then
        return existing
    end if
    fonts = m.top.theme.fonts
    group.removeChildrenIndex(group.getChildCount(), 0)
    nodes = []
    for i = 0 to m.visibleCount - 1
        holder = group.createChild("Rectangle")
        holder.translation = [
            0
            i * m.rowHeight
        ]
        holder.width = m.columnWidth
        holder.height = m.rowHeight
        marker = holder.createChild("Rectangle")
        label = holder.createChild("Label")
        setFont(label, fonts, fonts.bodySize)
        nodes.push({
            holder: holder
            marker: marker
            label: label
        })
    end for
    return nodes
end function

' ==========================================================================
' RENDER
' ==========================================================================
sub render()
    theme = m.top.theme
    if not rbp_isAA(theme) or not rbp_isAA(theme.colors) then
        return
    end if
    if m.audioNodes.count() = 0 then
        return
    end if
    colors = theme.colors
    audioActive = m.top.kind <> "subtitle"
    renderColumn(m.audioNodes, m.top.audioRows, audioActive, m.audioHead, m.audioRule, m.audioMore, colors)
    renderColumn(m.subtitleNodes, m.top.subtitleRows, not audioActive, m.subtitleHead, m.subtitleRule, m.subtitleMore, colors)
end sub

sub renderColumn(nodes as object, rows as dynamic, active as boolean, head as object, rule as object, more as object, colors as object)
    if not rbp_isArray(rows) then
        rows = []
    end if
    ' The active column is the one the keys move in. Nothing is focusable,
    ' so colour is the only thing saying which one that is - its header is
    ' full-strength with an accent rule, the other is muted.
    if active
        head.color = colors.text
        rule.color = colors.primary
        highlightIndex = m.top.index
    else
        head.color = colors.textMuted
        rule.color = colors.textMuted
        highlightIndex = -1
    end if
    ' The inactive column scrolls to its own selection, so what is chosen
    ' there is always on screen even while the user works in the other one.
    anchor = highlightIndex
    if not active then
        anchor = rbp_menuSelectedIndex(rows)
    end if
    start = rbp_menuWindowStart(anchor, m.visibleCount, rows.count())
    markerSize = int(m.rowHeight / 5)
    if markerSize < 6 then
        markerSize = 6
    end if
    for i = 0 to nodes.count() - 1
        node = nodes[i]
        rowIndex = start + i
        if rowIndex > rows.count() - 1
            node.holder.visible = false
        else
            row = rows[rowIndex]
            node.holder.visible = true
            highlighted = rowIndex = highlightIndex
            ' A filled row, not an outline: at across-the-room distance a 2px
            ' border is not reliably visible.
            if highlighted
                node.holder.color = colors.primary
                node.label.color = colors.background
                node.marker.color = colors.background
            else
                node.holder.color = "0x00000000"
                node.marker.color = colors.primary
                ' The applied row stays full-strength in both columns; the
                ' rest of an inactive column recedes.
                if active or row.selected = true
                    node.label.color = colors.text
                else
                    node.label.color = colors.textMuted
                end if
            end if
            ' A dot rather than a tick glyph. Non-ASCII in a Label is still
            ' unverified on this device (see P5), and a Rectangle cannot fail
            ' to render.
            node.marker.visible = row.selected = true
            node.marker.width = markerSize
            node.marker.height = markerSize
            node.marker.translation = [
                m.gap
                int((m.rowHeight - markerSize) / 2)
            ]
            node.label.text = row.label
            node.label.translation = [
                m.gap * 2 + markerSize
                int(m.gap / 4)
            ]
            node.label.width = m.columnWidth - (m.gap * 3 + markerSize)
        end if
    end for
    ' Position in a long list, only when the list is actually longer than
    ' the column. "6 of 14" answers both "is there more?" and "how far
    ' down am I?" in one line, which a lone ellipsis does not.
    overflow = rows.count() > m.visibleCount
    more.visible = overflow
    if overflow
        more.text = Str(anchor + 1).Trim() + " of " + Str(rows.count()).Trim()
    end if
end sub

' ==========================================================================
' FONTS
'
' Same tactic as the controls overlay: a themed size only if a real ttf can
' be resolved, otherwise the nearest built-in. A Font node with an
' unresolvable uri renders NOTHING at all, and invisible text is worse than
' text at the wrong size.
' ==========================================================================
sub setFont(label as object, fonts as object, size as dynamic, bold = false as boolean)
    uri = resolveFontUri(fonts)
    if uri <> ""
        font = CreateObject("roSGNode", "Font")
        font.uri = uri
        font.size = rbp_toPositiveInt(size)
        label.font = font
        return
    end if
    label.font = systemFontFor(rbp_toPositiveInt(size), bold)
end sub

function resolveFontUri(fonts as object) as string
    if rbp_isNonEmptyString(fonts.family) then
        return fonts.family
    end if
    if m.systemFontUri <> invalid then
        return m.systemFontUri
    end if
    fs = CreateObject("roFileSystem")
    for each candidate in [
        "common:/Fonts/Roboto-Medium.ttf"
        "common:/Fonts/Roboto-Regular.ttf"
        "common:/Fonts/RobotoCondensed-Regular.ttf"
    ]
        if fs.Exists(candidate)
            m.systemFontUri = candidate
            return candidate
        end if
    end for
    m.systemFontUri = ""
    return ""
end function

function systemFontFor(size as integer, bold as boolean) as string
    if size <= 20
        name = "Smallest"
    else if size <= 26
        name = "Small"
    else if size <= 34
        name = "Medium"
    else
        name = "Large"
    end if
    if bold then
        return "font:" + name + "BoldSystemFont"
    end if
    return "font:" + name + "SystemFont"
end function
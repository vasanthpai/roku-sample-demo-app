'import "pkg:/source/rbp/rbpFormat.bs"
'import "pkg:/source/rbp/rbpScrubber.bs"
'import "pkg:/source/rbp/rbpTrickPlay.bs"
'import "pkg:/source/rbp/rbpOverlay.bs"
'import "pkg:/source/rbp/rbpButtonRow.bs"
'import "pkg:/source/rbp/rbpPlayerState.bs"
'import "pkg:/source/rbp/rbpUtils.bs"
' The SDK's own glyphs. Inside a ComponentLibrary pkg:/ resolves to the
' LIBRARY's package, which is exactly what is wanted here - these ship in
' rbp-lib-<version>.zip and are found no matter what the host app contains.
'
' They are white alpha masks, so Poster.blendColor tints the whole set from
' one theme colour. That is why there is no "icon colour" token: the glyphs
' follow colors.text and colors.primary like everything else.





' The focus plate behind a highlighted glyph. Tinted from colors.primary, so
' a client's brand colour is also their focus colour with no extra token.

' Poster tints by multiplying, so opaque white is "leave it alone".


sub init()
    m.systemFontUri = invalid
    m.ratingVisible = false
    m.hasRating = false
    m.customPlay = false
    m.customPause = false
    m.customRewind = false
    m.customForward = false
    m.customSubtitles = false
    m.ratingPad = 8
    m.chrome = m.top.findNode("chrome")
    m.scrim = m.top.findNode("scrim")
    m.topScrim = m.top.findNode("topScrim")
    m.metadata = m.top.findNode("metadata")
    m.logo = m.top.findNode("logo")
    m.title = m.top.findNode("title")
    m.controlBar = m.top.findNode("controlBar")
    m.status = m.top.findNode("status")
    m.speed = m.top.findNode("speed")
    m.track = m.top.findNode("track")
    m.fill = m.top.findNode("fill")
    m.thumb = m.top.findNode("thumb")
    m.elapsed = m.top.findNode("elapsed")
    m.remaining = m.top.findNode("remaining")
    m.iconRow = m.top.findNode("iconRow")
    m.iconRewind = m.top.findNode("iconRewind")
    m.iconPlayPause = m.top.findNode("iconPlayPause")
    m.iconForward = m.top.findNode("iconForward")
    m.plateRewind = m.top.findNode("plateRewind")
    m.platePlayPause = m.top.findNode("platePlayPause")
    m.plateForward = m.top.findNode("plateForward")
    for each plate in [
        m.plateRewind
        m.platePlayPause
        m.plateForward
    ]
        plate.uri = "pkg:/images/rbp-focus.png"
        plate.visible = false
    end for
    m.tracksButton = m.top.findNode("tracksButton")
    m.tracksIcon = m.top.findNode("tracksIcon")
    m.tracksLabel = m.top.findNode("tracksLabel")
    m.tracksLabel.text = "Audio & Subtitles"
    m.ratingBug = m.top.findNode("ratingBug")
    m.ratingBug.visible = false
    m.rating = m.top.findNode("rating")
    m.top.observeField("theme", "onThemeChanged")
    m.top.observeField("size", "onSizeChanged")
    m.top.observeField("playerState", "onPlaybackChanged")
    m.top.observeField("position", "onPlaybackChanged")
    m.top.observeField("duration", "onPlaybackChanged")
    m.top.observeField("mediaItem", "onMediaItemChanged")
    m.top.observeField("trickPlay", "onPlaybackChanged")
    m.top.observeField("chromeVisible", "onChromeVisibleChanged")
    m.top.observeField("focusedButton", "onPlaybackChanged")
end sub

' Auto-hide takes the chrome only. The rating bug and the buffering notice
' are siblings of it and stay on screen.
sub onChromeVisibleChanged()
    m.chrome.visible = m.top.chromeVisible
end sub

' ==========================================================================
' THEME
'
' Applied to every node, then the layout is recomputed - a size token such
' as iconSize changes geometry, not just colour.
' ==========================================================================
sub onThemeChanged()
    theme = m.top.theme
    if not rbp_isAA(theme) then
        return
    end if
    if not rbp_isAA(theme.colors) then
        return
    end if
    colors = theme.colors
    fonts = theme.fonts
    m.scrim.color = colors.overlay
    m.topScrim.color = colors.overlay
    m.title.color = colors.text
    setFont(m.title, fonts, fonts.titleSize, true)
    m.ratingBug.color = colors.surface
    m.rating.color = colors.text
    setFont(m.rating, fonts, fonts.captionSize)
    m.status.color = colors.text
    setFont(m.status, fonts, fonts.bodySize, true)
    ' The speed readout is the accent colour: while scanning it is the one
    ' thing on screen the user is actively steering.
    m.speed.color = colors.primary
    setFont(m.speed, fonts, fonts.bodySize, true)
    m.track.color = colors.textMuted
    m.fill.color = colors.primary
    m.thumb.color = colors.primary
    m.elapsed.color = colors.text
    setFont(m.elapsed, fonts, fonts.captionSize)
    m.remaining.color = colors.textMuted
    setFont(m.remaining, fonts, fonts.captionSize)
    setFont(m.tracksLabel, fonts, fonts.bodySize, true)
    applyIconSources()
    applyLayout()
    render()
end sub

' ==========================================================================
' ICONS
'
' Affordances, not widgets - they show which key does what and reflect real
' state, but nothing here takes focus. See docs/P7-controls.md.
'
' A client asset replaces the bundled glyph and is drawn UNTINTED. Tinting
' someone's branded artwork down to a flat colour destroys it, and a client
' who supplied a specific icon has already made the colour decision.
' ==========================================================================
sub applyIconSources()
    theme = m.top.theme
    if not rbp_isAA(theme.assets) then
        return
    end if
    a = theme.assets
    m.customPlay = rbp_isNonEmptyString(a.iconPlay)
    m.customPause = rbp_isNonEmptyString(a.iconPause)
    m.customRewind = rbp_isNonEmptyString(a.iconRewind)
    m.customForward = rbp_isNonEmptyString(a.iconForward)
    m.customSubtitles = rbp_isNonEmptyString(a.iconCaptions)
    m.tracksIcon.uri = iconUri(a.iconCaptions, "pkg:/images/rbp-subtitles.png")
    m.iconRewind.uri = iconUri(a.iconRewind, "pkg:/images/rbp-rewind.png")
    m.iconForward.uri = iconUri(a.iconForward, "pkg:/images/rbp-forward.png")
    ' Play/pause is chosen per render, so its uri is set there.
    size = rbp_toPositiveInt(theme.sizes.iconSize)
    for each icon in [
        m.iconRewind
        m.iconPlayPause
        m.iconForward
    ]
        icon.width = size
        icon.height = size
    end for
end sub

function iconUri(clientUrl as dynamic, bundled as string) as string
    if rbp_isNonEmptyString(clientUrl) then
        return clientUrl
    end if
    return bundled
end function

' Tint a bundled glyph; leave a client's own artwork alone.
sub tintIcon(icon as object, isCustom as dynamic, color as string)
    if isCustom = true
        icon.blendColor = "0xFFFFFFFF"
        return
    end if
    icon.blendColor = color
end sub

' A sized Font node, or invalid if one cannot be built.
'
' A Font whose uri does not resolve renders NOTHING - not a fallback face,
' not a box, nothing. Returning invalid lets the caller keep the XML's
' guaranteed system font instead, because the wrong size is a cosmetic
' problem and invisible text is not.
'
' The candidate list is the same tactic as track key names in P5: several
' plausible system paths tried in order rather than one asserted.
function makeFont(fonts as object, size as dynamic) as object
    uri = resolveFontUri(fonts)
    if uri = "" then
        return invalid
    end if
    font = CreateObject("roSGNode", "Font")
    font.uri = uri
    font.size = rbp_toPositiveInt(size)
    return font
end function

function resolveFontUri(fonts as object) as string
    ' A client font wins outright. P6 already refused any pkg:/ path, so
    ' anything here is a url Roku can fetch.
    if rbp_isNonEmptyString(fonts.family) then
        return fonts.family
    end if
    if m.systemFontUri <> invalid then
        return m.systemFontUri
    end if
    fs = CreateObject("roFileSystem")
    for each candidate in [
        "common:/Fonts/Roboto-Medium.ttf"
        "common:/Fonts/Roboto-Regular.ttf"
        "common:/Fonts/RobotoCondensed-Regular.ttf"
    ]
        if fs.Exists(candidate)
            m.systemFontUri = candidate
            print "[rbp] overlay font: " + candidate
            return candidate
        end if
    end for
    ' None found. The XML's font:MediumBoldSystemFont stays in place and the
    ' themed sizes are ignored - reported once so it is not a silent downgrade.
    m.systemFontUri = ""
    print "[rbp] overlay font: no system ttf found, using fixed system fonts"
    return ""
end function

' Assign a font for a role.
'
' With a real ttf - a client's own, or a system file if one exists - the
' themed size is used exactly. Without one, the size snaps to the nearest of
' Roku's four built-in sizes.
'
' Snapping is approximate, but it means a client raising titleSize gets a
' bigger title rather than nothing at all. Verified on device: neither
' common:/Fonts path exists, so this is the path most players will take.
sub setFont(label as object, fonts as object, size as dynamic, bold = false as boolean)
    font = makeFont(fonts, size)
    if font <> invalid
        label.font = font
        return
    end if
    label.font = systemFontFor(rbp_toPositiveInt(size), bold)
end sub

' Nearest built-in font for a themed size.
'
' The thresholds are 720p-relative, matching the default token scale
' (caption 18, body 24, title 34).
function systemFontFor(size as integer, bold as boolean) as string
    if size <= 20
        name = "Smallest"
    else if size <= 26
        name = "Small"
    else if size <= 34
        name = "Medium"
    else
        name = "Large"
    end if
    if bold then
        return "font:" + name + "BoldSystemFont"
    end if
    return "font:" + name + "SystemFont"
end function

' ==========================================================================
' LAYOUT
'
' Every offset comes from a spacing or size token, so a client widening
' barPadding moves the whole bar rather than nothing at all.
'
' Laid out BOTTOM-UP from the safe area. Any section a client switches off
' contributes no height, so the stack closes up instead of leaving a hole
' where the section used to be - the same fix the age badge needed when its
' row was reserved unconditionally.
' ==========================================================================
sub onSizeChanged()
    applyLayout()
    render()
end sub

sub applyLayout()
    theme = m.top.theme
    if not rbp_isAA(theme) or not rbp_isAA(theme.sizes) then
        return
    end if
    if not rbp_isAA(theme.controls) then
        return
    end if
    size = m.top.size
    if size = invalid then
        return
    end if
    w = size[0]
    h = size[1]
    controls = theme.controls
    pad = rbp_toPositiveInt(theme.spacing.barPadding)
    gap = rbp_toPositiveInt(theme.spacing.gap)
    trackHeight = rbp_toPositiveInt(theme.sizes.scrubberHeight)
    iconSize = rbp_toPositiveInt(theme.sizes.iconSize)
    titleSize = rbp_toPositiveInt(theme.fonts.titleSize)
    captionSize = rbp_toPositiveInt(theme.fonts.captionSize)
    bodySize = rbp_toPositiveInt(theme.fonts.bodySize)
    showIcons = controls.showIcons = true
    showTimes = controls.showTimes = true
    showScrubber = controls.showScrubber = true
    ' A handle, not a block. At iconSize/2 a 24px square sat on an 8px track
    ' and read as a stray marker rather than part of the scrubber.
    thumbSize = trackHeight * 2
    if thumbSize < 16 then
        thumbSize = 16
    end if
    innerWidth = w - pad * 2
    if innerWidth < 0 then
        innerWidth = 0
    end if
    m.barWidth = innerWidth
    ' TV overscan eats roughly the outer 5%.
    safeInset = int(h * 0.05)
    safeBottom = h - safeInset
    ' --- bottom-up stack ---
    '
    ' Reading DOWN the screen the order is: progress bar, the times that
    ' annotate it, then the controls. The glyphs sit BELOW the bar because
    ' they are what the user acts on - putting them above pushes the bar to
    ' the very bottom edge, closest to the overscan margin, which is the one
    ' element that must never be clipped.
    cursor = safeBottom
    ' The icon row and the status/speed text share a row: the glyphs are
    ' centred and the text sits right-aligned beside them. Two rows would
    ' waste a band of screen on a label that is usually empty.
    showButton = controls.showMenus = true
    ' The row is as tall as its tallest occupant. The button is taller than
    ' a line of text, so with glyphs switched off it would otherwise overhang
    ' the row and collide with the times above it.
    buttonHeight = bodySize + gap
    rowHeight = bodySize
    if showIcons and iconSize > rowHeight then
        rowHeight = iconSize
    end if
    if showButton and buttonHeight > rowHeight then
        rowHeight = buttonHeight
    end if
    rowTop = cursor - rowHeight
    cursor = rowTop - int(gap / 2)
    timesTop = cursor
    if showTimes
        timesTop = cursor - captionSize
        cursor = timesTop - int(gap / 2)
    end if
    trackTop = cursor
    if showScrubber
        trackTop = cursor - trackHeight
        cursor = trackTop - int(gap / 2)
    end if
    ' --- control bar ---
    ' Anchored to whichever element is now topmost in the group.
    barTop = trackTop
    m.controlBar.translation = [
        pad
        barTop
    ]
    ' Text is centred against the icon row so a 48px glyph and a 24px label
    ' sit on the same optical line.
    textTop = (rowTop - barTop) + int((rowHeight - bodySize) / 2)
    if textTop < 0 then
        textTop = 0
    end if
    ' Status and speed sit on the LEFT of the row now. The right is the
    ' button's, and the glyphs hold the centre.
    m.status.translation = [
        0
        textTop
    ]
    m.speed.translation = [
        0
        textTop
    ]
    m.speed.width = int(innerWidth / 3)
    m.speed.horizAlign = "left"
    m.iconRow.visible = showIcons
    if showIcons
        iconStart = rbp_centeredRowStart(3, iconSize, gap, innerWidth)
        m.iconRow.translation = [
            iconStart
            rowTop - barTop
        ]
        m.iconRewind.translation = [
            0
            0
        ]
        m.iconPlayPause.translation = [
            iconSize + gap
            0
        ]
        m.iconForward.translation = [
            (iconSize + gap) * 2
            0
        ]
        ' Plates a little larger than the glyph and centred on it, so the
        ' glyph sits inside a disc rather than being cropped by one.
        plateSize = iconSize + int(gap / 2)
        inset = int((plateSize - iconSize) / 2)
        slots = [
            [
                m.plateRewind
                0
            ]
            [
                m.platePlayPause
                1
            ]
            [
                m.plateForward
                2
            ]
        ]
        for each slot in slots
            slot[0].width = plateSize
            slot[0].height = plateSize
            slot[0].translation = [
                (iconSize + gap) * slot[1] - inset
                -inset
            ]
        end for
    end if
    ' --- the button, right-aligned on the same row ---
    m.tracksButton.visible = showButton
    if showButton
        buttonPad = gap
        glyph = buttonHeight - int(gap / 2)
        ' Measure the label rather than guessing from its length. A guess
        ' either clips "Audio & Subtitles" or leaves a slab of padding, and
        ' the text will be a client's own string once labels are themeable.
        labelWidth = m.tracksLabel.boundingRect().width
        if labelWidth <= 0 then
            labelWidth = int(len(m.tracksLabel.text) * bodySize * 0.55)
        end if
        buttonWidth = buttonPad + glyph + int(gap / 2) + labelWidth + buttonPad
        m.tracksButton.width = buttonWidth
        m.tracksButton.height = buttonHeight
        m.tracksButton.translation = [
            innerWidth - buttonWidth
            (rowTop - barTop) + int((rowHeight - buttonHeight) / 2)
        ]
        m.tracksIcon.width = glyph
        m.tracksIcon.height = glyph
        m.tracksIcon.translation = [
            buttonPad
            int((buttonHeight - glyph) / 2)
        ]
        m.tracksLabel.translation = [
            buttonPad + glyph + int(gap / 2)
            int((buttonHeight - bodySize) / 2) - 2
        ]
    end if
    m.elapsed.visible = showTimes
    m.remaining.visible = showTimes
    m.elapsed.translation = [
        0
        timesTop - barTop
    ]
    m.remaining.translation = [
        0
        timesTop - barTop
    ]
    m.remaining.width = innerWidth
    m.remaining.horizAlign = "right"
    m.track.visible = showScrubber
    m.thumb.visible = showScrubber
    m.track.width = innerWidth
    m.track.height = trackHeight
    m.track.translation = [
        0
        trackTop - barTop
    ]
    m.fill.height = trackHeight
    m.thumb.width = thumbSize
    m.thumb.height = thumbSize
    m.thumbSize = thumbSize
    m.thumbTop = (trackTop - barTop) + int(trackHeight / 2) - int(thumbSize / 2)
    ' --- metadata, TOP-left ---
    '
    ' The title used to sit directly above the bar, where it competed with
    ' the controls for the same corner of the screen and repeated whatever
    ' the client's own launch screen had already said. It is off by default
    ' now, and when on it lives at the top, out of the controls' way.
    showTitle = controls.showTitle = true
    m.metadata.visible = showTitle
    m.metadata.translation = [
        pad
        safeInset
    ]
    ' Only as tall as the title it protects, and gone entirely when there is
    ' no title to protect.
    m.topScrim.visible = showTitle
    m.topScrim.width = w
    m.topScrim.height = safeInset + titleSize + gap
    m.topScrim.translation = [
        0
        0
    ]
    m.title.translation = [
        0
        0
    ]
    m.title.width = innerWidth
    m.logo.translation = [
        0
        0
    ]
    ' --- scrim, only as tall as the content it sits behind ---
    scrimTop = cursor - gap
    if scrimTop < 0 then
        scrimTop = 0
    end if
    m.scrim.width = w
    m.scrim.height = h - scrimTop
    m.scrim.translation = [
        0
        scrimTop
    ]
    ' --- rating bug, top-left, under the title when there is one ---
    m.ratingPad = int(gap / 2)
    ratingTop = safeInset
    if showTitle then
        ratingTop = safeInset + titleSize + int(gap / 2)
    end if
    m.ratingBug.translation = [
        pad
        ratingTop
    ]
    m.ratingBug.height = captionSize + gap
    m.rating.translation = [
        m.ratingPad
        int(gap / 4)
    ]
    sizeRatingBug()
end sub

' Sized from the text: a fixed box either clips "TV-MA" or leaves a slab of
' surface colour beside "U".
sub sizeRatingBug()
    if not m.hasRating then
        return
    end if
    theme = m.top.theme
    if not rbp_isAA(theme) or not rbp_isAA(theme.fonts) then
        return
    end if
    charWidth = rbp_toPositiveInt(theme.fonts.captionSize) * 0.6
    m.ratingBug.width = len(m.rating.text) * charWidth + m.ratingPad * 2
end sub

' ==========================================================================
' RENDER
' ==========================================================================
sub onPlaybackChanged()
    render()
end sub

sub onMediaItemChanged()
    item = m.top.mediaItem
    if not rbp_isAA(item) then
        return
    end if
    m.title.text = ""
    if rbp_isNonEmptyString(item.title) then
        m.title.text = item.title
    end if
    m.hasRating = rbp_isNonEmptyString(item.ageRating)
    if m.hasRating
        m.rating.text = item.ageRating
        sizeRatingBug()
    end if
    render()
end sub

sub render()
    theme = m.top.theme
    if not rbp_isAA(theme) then
        return
    end if
    if m.barWidth = invalid then
        return
    end if
    controls = theme.controls
    colors = theme.colors
    trick = m.top.trickPlay
    scanning = rbp_isAA(trick) and trick.active = true
    ' While scanning the bar follows where the user is heading, not where
    ' playback is parked. Showing the real position would make the scrubber
    ' look frozen while they scan.
    shown = m.top.position
    if scanning then
        shown = trick.previewPosition
    end if
    duration = m.top.duration
    m.fill.width = rbp_fillWidth(shown, duration, m.barWidth)
    m.thumb.translation = [
        rbp_thumbX(shown, duration, m.barWidth, m.thumbSize) - int(m.thumbSize / 2)
        m.thumbTop
    ]
    m.elapsed.text = rbp_formatTime(shown)
    m.remaining.text = rbp_formatRemaining(shown, duration)
    renderIcons(scanning, trick, colors, controls)
    renderButton(colors)
    if scanning
        ' displaySpeed, not speed. The rate is 5x/30x/60x; the indicator
        ' reads 2x/3x/4x, because on a three-notch remote the notch number
        ' is what the user is tracking.
        m.speed.text = rbp_formatSpeed(trick.direction, trick.displaySpeed)
        m.status.text = ""
    else
        m.speed.text = ""
        m.status.text = statusText(m.top.playerState, controls.showIcons = true)
    end if
    ' No buffering notice of our own. The Video node already draws one, and
    ' running both put a spinner and the word "Buffering..." on screen at the
    ' same time for the same condition - which reads as a fault rather than
    ' as feedback. Roku's is also drawn by the Video node itself, so it is
    ' unaffected by auto-hide without us having to arrange anything.
    renderRatingBug(controls)
    applyLogo()
end sub

' The glyph shows the ACTION the key will perform, which is why it is the
' pause bars while playing. Showing current state instead makes people press
' it expecting the opposite of what happens.
sub renderIcons(scanning as boolean, trick as dynamic, colors as object, controls as object)
    if controls.showIcons <> true then
        return
    end if
    assets = m.top.theme.assets
    if m.top.playerState = "playing"
        m.iconPlayPause.uri = iconUri(assets.iconPause, "pkg:/images/rbp-pause.png")
        tintIcon(m.iconPlayPause, m.customPause, colors.text)
    else
        m.iconPlayPause.uri = iconUri(assets.iconPlay, "pkg:/images/rbp-play.png")
        tintIcon(m.iconPlayPause, m.customPlay, colors.text)
    end if
    ' The direction being scanned lights up in the accent colour, so the
    ' glyphs report trick play state rather than sitting inert.
    rewindColor = colors.text
    forwardColor = colors.text
    if scanning
        if trick.direction < 0
            rewindColor = colors.primary
        else
            forwardColor = colors.primary
        end if
    end if
    ' A focused glyph sits on an accent-coloured plate and flips to the
    ' background colour, so it stays legible against its own highlight.
    focus = m.top.focusedButton
    focusGlyph(m.plateRewind, m.iconRewind, m.customRewind, focus = "rewind", rewindColor, colors)
    focusGlyph(m.plateForward, m.iconForward, m.customForward, focus = "forward", forwardColor, colors)
    playPauseCustom = m.customPlay
    if m.top.playerState = "playing" then
        playPauseCustom = m.customPause
    end if
    focusGlyph(m.platePlayPause, m.iconPlayPause, playPauseCustom, focus = "playPause", colors.text, colors)
end sub

sub focusGlyph(plate as object, icon as object, isCustom as dynamic, focused as boolean, restingColor as string, colors as object)
    plate.visible = focused
    plate.blendColor = colors.primary
    if focused
        tintIcon(icon, isCustom, colors.background)
    else
        tintIcon(icon, isCustom, restingColor)
    end if
end sub

' Filled in the accent colour when the user is on it, quiet otherwise.
'
' A fill rather than an outline: at across-the-room distance a 2px border is
' not reliably visible, and "which thing am I on" is the one question this
' state has to answer at a glance.
sub renderButton(colors as object)
    if not m.tracksButton.visible then
        return
    end if
    if m.top.focusedButton = "tracks"
        m.tracksButton.color = colors.primary
        m.tracksLabel.color = colors.background
        tintIcon(m.tracksIcon, m.customSubtitles, colors.background)
    else
        m.tracksButton.color = colors.surface
        m.tracksLabel.color = colors.text
        tintIcon(m.tracksIcon, m.customSubtitles, colors.text)
    end if
end sub

sub renderRatingBug(controls as object)
    visible = rbp_shouldShowRatingBug(m.hasRating, controls.showRatingBug = true, m.top.position, controls.ratingBugSeconds)
    if visible = m.ratingVisible then
        return
    end if
    m.ratingVisible = visible
    m.ratingBug.visible = visible
end sub

' With icons on, "Playing" and "Paused" are already said by the glyph, so
' this only reports what a glyph cannot. With icons off it carries the lot.
function statusText(playerState as dynamic, hasIcons as boolean) as string
    if playerState = "ended" then
        return "Ended"
    end if
    if playerState = "error" then
        return "Error"
    end if
    if hasIcons then
        return ""
    end if
    ' Buffering is absent on purpose even here: the Video node's own
    ' indicator covers it in every configuration.
    if playerState = "playing" then
        return "Playing"
    end if
    if playerState = "paused" then
        return "Paused"
    end if
    return ""
end function

' The logo is only shown when a client supplied one. P6 already refused any
' pkg:/ path, so anything reaching here is a URL Roku can fetch.
sub applyLogo()
    theme = m.top.theme
    if not rbp_isAA(theme) or not rbp_isAA(theme.assets) then
        return
    end if
    url = theme.assets.logo
    hasLogo = rbp_isNonEmptyString(url)
    m.logo.visible = hasLogo
    if hasLogo and m.logo.uri <> url
        m.logo.uri = url
        m.logo.height = rbp_toPositiveInt(theme.sizes.iconSize)
    end if
end sub
'import "pkg:/source/rbp/rbpTrack.bs"

sub init()
    m.video = m.top.findNode("video")
    m.backdrop = m.top.findNode("backdrop")
    m.observing = false
    m.top.observeField("size", "onSizeChanged")
    m.top.observeField("theme", "onThemeChanged")
    m.top.observeField("notificationInterval", "onIntervalChanged")
    applySize()
    applyInterval()
    startObserving()
end sub

' ==========================================================================
' OBSERVER LIFECYCLE
'
' Every observeField below has a matching unobserveField in dispose(). This
' is the single biggest source of Roku memory leaks - a node kept alive by a
' dangling observer is never collected. P11 audits this across the codebase;
' the discipline starts here, with one component, where it is cheap.
' ==========================================================================
sub startObserving()
    if m.observing then
        return
    end if
    m.video.observeField("state", "onVideoState")
    m.video.observeField("position", "onVideoPosition")
    m.video.observeField("duration", "onVideoDuration")
    ' errorCode only - observing errorMsg too would double-fire for one error.
    m.video.observeField("errorCode", "onVideoError")
    m.video.observeField("availableAudioTracks", "onAudioTracks")
    m.video.observeField("availableSubtitleTracks", "onSubtitleTracks")
    m.video.observeField("globalCaptionMode", "onCaptionMode")
    m.observing = true
end sub

' PUBLIC. Idempotent - safe to call twice, safe to call before playback.
' Takes an unused parameter because callFunc requires the argument count to
' match the signature exactly.
sub dispose(unused = invalid as dynamic)
    if m.observing
        m.video.unobserveField("state")
        m.video.unobserveField("position")
        m.video.unobserveField("duration")
        m.video.unobserveField("errorCode")
        m.video.unobserveField("availableAudioTracks")
        m.video.unobserveField("availableSubtitleTracks")
        m.video.unobserveField("globalCaptionMode")
        m.observing = false
    end if
    m.video.control = "stop"
    m.video.content = invalid
end sub

' ==========================================================================
' NODE HANDLERS - forward only, no logic
' ==========================================================================
sub onVideoState()
    m.top.rawState = m.video.state
end sub

sub onVideoPosition()
    m.top.position = m.video.position
end sub

sub onVideoDuration()
    m.top.duration = m.video.duration
end sub

sub onVideoError()
    m.top.videoError = {
        code: m.video.errorCode
        message: m.video.errorMsg
    }
end sub

' ==========================================================================
' TRACKS
'
' Roku reports these repeatedly while a manifest parses, usually unchanged,
' and an array field notifies on EVERY assignment. Publishing an identical
' list would wake the client for nothing and rebuild a menu under the user.
' ==========================================================================
sub onAudioTracks()
    tracks = rbp_normalizeTracks(m.video.availableAudioTracks, "audio")
    if rbp_tracksEqual(m.top.audioTracks, tracks) then
        return
    end if
    m.top.audioTracks = tracks
end sub

sub onSubtitleTracks()
    tracks = rbp_normalizeTracks(m.video.availableSubtitleTracks, "subtitle")
    if rbp_tracksEqual(m.top.subtitleTracks, tracks) then
        return
    end if
    m.top.subtitleTracks = tracks
end sub

sub onCaptionMode()
    m.top.captionMode = m.video.globalCaptionMode
end sub

' Selection. The id has already been validated against the available list by
' the Facade - Roku ignores an unknown id in silence, so it never reaches here.
sub selectAudioTrack(trackId as string)
    m.video.audioTrack = trackId
end sub

' An empty id turns subtitles off.
sub selectSubtitleTrack(trackId as string)
    m.video.subtitleTrack = trackId
end sub

' ==========================================================================
' PUBLIC FUNCTIONS - the only way in
' ==========================================================================
sub setContent(contentNode as object)
    ' Stop BEFORE swapping content.
    '
    ' Without this the Video node keeps reporting the previous stream for a
    ' moment after the new content is assigned: a stale "playing" arrives
    ' against the fresh session, firing a meaningless playbackStart, and the
    ' genuine initial buffer that follows is then misclassified as a stall.
    ' That corrupts startup time and rebuffer count - the two numbers this
    ' SDK most needs to get right.
    m.video.control = "stop"
    m.video.content = contentNode
end sub

sub applyControl(controlValue as string)
    if controlValue = "" then
        return
    end if
    m.video.control = controlValue
end sub

sub seekTo(positionSeconds as integer)
    m.video.seek = positionSeconds
end sub

' ==========================================================================
' LAYOUT
' ==========================================================================
sub onSizeChanged()
    applySize()
end sub

sub applySize()
    size = m.top.size
    if size = invalid then
        return
    end if
    m.video.width = size[0]
    m.video.height = size[1]
    m.backdrop.width = size[0]
    m.backdrop.height = size[1]
end sub

sub onThemeChanged()
    theme = m.top.theme
    if theme = invalid or theme.colors = invalid then
        return
    end if
    m.backdrop.color = theme.colors.background
end sub

sub onIntervalChanged()
    applyInterval()
end sub

' Controls how often the Video node fires `position`. Roku's default is more
' frequent than most clients want; P3 adds client-facing throttling on top.
sub applyInterval()
    m.video.notificationInterval = m.top.notificationInterval
end sub
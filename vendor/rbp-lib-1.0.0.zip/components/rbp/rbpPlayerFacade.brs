'import "pkg:/source/rbp/rbpContentMapper.bs"
'import "pkg:/source/rbp/rbpContentNode.bs"
'import "pkg:/source/rbp/rbpPlaybackRules.bs"
'import "pkg:/source/rbp/rbpSession.bs"
'import "pkg:/source/rbp/rbpTrack.bs"
'import "pkg:/source/rbp/rbpTheme.bs"
'import "pkg:/source/rbp/rbpAnalytics.bs"
'import "pkg:/source/rbp/rbpPlayerState.bs"
'import "pkg:/source/rbp/rbpPlayerEvent.bs"
'import "pkg:/source/rbp/rbpErrorCode.bs"
'import "pkg:/source/rbp/rbpUtils.bs"

sub init()
    ' Monotonic millisecond clock. Every session timing is a difference
    ' between two readings, so the origin does not matter.
    m.clock = CreateObject("roTimespan")
    m.session = rbp_newSession(clockMs())
    m.lastPositionMs = 0
    m.lastStats = invalid
    m.analyticsSequence = 0
    m.top.playerState = "idle"
    m.top.errorInfo = {
        code: "none"
        message: ""
    }
    m.item = invalid
    m.content = invalid
    m.observing = false
    m.wrapper = m.top.findNode("videoWrapper")
    m.wrapper.observeField("rawState", "onRawState")
    m.wrapper.observeField("position", "onWrapperPosition")
    m.wrapper.observeField("duration", "onWrapperDuration")
    m.wrapper.observeField("videoError", "onWrapperError")
    m.wrapper.observeField("audioTracks", "onWrapperAudioTracks")
    m.wrapper.observeField("subtitleTracks", "onWrapperSubtitleTracks")
    m.wrapper.observeField("captionMode", "onWrapperCaptionMode")
    m.observing = true
    m.top.observeField("size", "onSizeChanged")
    m.wrapper.size = m.top.size
    ' Start on the defaults so the player is fully styled before a client
    ' calls setTheme() - and stays styled if they never do.
    applyTheme(invalid)
    publishStats()
    print "[rbpPlayerFacade] init"
end sub
' ==========================================================================
' PUBLIC API
' ==========================================================================

' facade.callFunc("load", mediaItem)
function load(source as dynamic) as object
    result = rbp_buildContent(source)
    if not result.ok
        m.item = invalid
        m.content = invalid
        m.top.mediaItem = {}
        m.top.duration = 0
        m.top.errorInfo = {
            code: result.code
            message: result.message
        }
        return {
            ok: false
            code: result.code
            message: result.message
        }
    end if
    node = rbp_toContentNode(result.content)
    if node = invalid
        m.top.errorInfo = {
            code: "unknown"
            message: "could not build content node"
        }
        return {
            ok: false
            code: "unknown"
            message: "could not build content node"
        }
    end if
    m.item = result.item
    m.content = result.content
    m.top.mediaItem = result.item
    m.top.duration = result.content.length
    m.top.position = 0
    m.top.errorInfo = {
        code: "none"
        message: ""
    }
    ' A new item is a new session - every timing, counter and track resets.
    m.lastPositionMs = 0
    m.top.audioTracks = []
    m.top.subtitleTracks = []
    m.top.currentAudioTrack = ""
    m.top.currentSubtitleTrack = ""
    m.top.tracksReady = false
    applySession(rbp_sessionOnLoad(m.session, clockMs()))
    m.wrapper.callFunc("setContent", node)
    return {
        ok: true
        code: "none"
        message: ""
    }
end function

function play(unused = invalid as dynamic) as object
    return applyAction("play")
end function

function pause(unused = invalid as dynamic) as object
    return applyAction("pause")
end function

function stopPlayback(unused = invalid as dynamic) as object
    return applyAction("stop")
end function

function seek(positionSeconds = invalid as dynamic) as object
    ' Readiness must come from the STREAM, not from client metadata.
    ' m.top.duration is set optimistically by load() from the media item, so
    ' it is non-zero before the Video node has parsed anything. The wrapper's
    ' duration comes from Roku and is only set once the stream is ready.
    isReady = m.wrapper.duration > 0
    r = rbp_resolveSeek(positionSeconds, m.top.duration, isReady)
    if not r.ok
        return {
            ok: false
            code: "unknown"
            message: "seek rejected: " + r.reason
        }
    end if
    ' One seek in flight at a time. Without this, holding the remote key
    ' queues seeks that each trigger a full buffering cycle.
    s = rbp_sessionOnSeek(m.session, r.position, clockMs())
    if not s.accepted
        return {
            ok: false
            code: "unknown"
            message: "seek rejected: " + s.reason
        }
    end if
    applySession(s)
    m.wrapper.callFunc("seekTo", r.position)
    return {
        ok: true
        code: "none"
        message: ""
    }
end function

' PUBLIC. facade.callFunc("setTheme", { colors: { primary: "#E50914" } })
'
' Partial overrides deep-merge over the defaults, so anything omitted keeps
' its default value. Returns { ok, warnings }.
'
' A rejected token never fails the theme - it falls back and is reported in
' `warnings`. That matters most for assets: a pkg:/ path resolves to the
' LIBRARY's package inside a ComponentLibrary, so a client's own logo would
' load nothing with no error. The warning is how they find out.
'
' Call before load(). The theme is injected as the UI builds rather than
' applied afterwards as a restyle.
function setTheme(overrides = invalid as dynamic) as object
    return applyTheme(overrides)
end function

function applyTheme(overrides as dynamic) as object
    resolved = rbp_resolveTheme(overrides)
    m.top.theme = resolved.theme
    m.top.themeWarnings = resolved.warnings
    ' Push down explicitly rather than through m.global: inside a
    ' ComponentLibrary the global node is shared with the host app, so a
    ' client's own fields could collide with ours.
    m.wrapper.theme = resolved.theme
    for each warning in resolved.warnings
        print "[rbp] theme warning: " + warning.path + " -> " + warning.reason
    end for
    return {
        ok: true
        code: "none"
        message: ""
        warnings: resolved.warnings
    }
end function

' PUBLIC. facade.callFunc("selectAudioTrack", trackId)
'
' The id is validated against the available list before it reaches the Video
' node, because Roku ignores an unknown track id in silence - the client would
' otherwise believe the switch succeeded.
function selectAudioTrack(trackId = invalid as dynamic) as object
    return applyTrackSelection("audio", trackId)
end function

' PUBLIC. An empty id or invalid turns subtitles off.
function selectSubtitleTrack(trackId = invalid as dynamic) as object
    return applyTrackSelection("subtitle", trackId)
end function

function applyTrackSelection(kind as string, trackId as dynamic) as object
    isSubtitle = kind = "subtitle"
    if isSubtitle
        available = m.top.subtitleTracks
    else
        available = m.top.audioTracks
    end if
    ' Only subtitles can be turned off - there is no such thing as no audio.
    r = rbp_resolveTrackSelection(available, trackId, isSubtitle)
    if not r.ok
        return {
            ok: false
            code: "unknown"
            message: kind + " track rejected: " + r.reason
        }
    end if
    if isSubtitle
        m.wrapper.callFunc("selectSubtitleTrack", r.id)
        m.top.currentSubtitleTrack = r.id
    else
        m.wrapper.callFunc("selectAudioTrack", r.id)
        m.top.currentAudioTrack = r.id
    end if
    applySession(rbp_sessionOnTrackChange(m.session, kind, r.id, clockMs()))
    return {
        ok: true
        code: "none"
        message: ""
    }
end function

' PUBLIC. Clients call this when tearing the player down.
sub dispose(unused = invalid as dynamic)
    ' Report abandonment BEFORE tearing anything down. dispose() otherwise
    ' sets playerState directly, so no transition happens and the client
    ' never learns the session ended - an abandoned view would be
    ' indistinguishable from one that simply stopped reporting.
    if m.session.hasPlayed
        applySession(rbp_sessionOnRawState(m.session, "stopped", clockMs()))
    end if
    if m.observing
        m.wrapper.unobserveField("rawState")
        m.wrapper.unobserveField("position")
        m.wrapper.unobserveField("duration")
        m.wrapper.unobserveField("videoError")
        m.wrapper.unobserveField("audioTracks")
        m.wrapper.unobserveField("subtitleTracks")
        m.wrapper.unobserveField("captionMode")
        m.observing = false
    end if
    m.top.unobserveField("size")
    m.wrapper.callFunc("dispose", invalid)
    m.session = rbp_newSession(clockMs())
    m.lastStats = invalid
    m.analyticsSequence = 0
    m.top.playerState = "idle"
    m.top.isSeeking = false
    publishStats()
end sub

' ==========================================================================
' SESSION
'
' Single point where a session result is applied. Everything that changes
' player state goes through here, so the interface fields and the event
' trace can never drift apart.
' ==========================================================================
sub applySession(result as object)
    m.session = result.ctx
    m.top.playerState = result.ctx.state
    m.top.isSeeking = result.ctx.seekPending
    publishStats()
    for each evt in result.events
        print "[rbp] " + evt.name + " @" + Str(evt.atMs).Trim() + "ms " + formatMeta(evt.meta)
        if evt.name = "seekEnd" then
            publishSeekLanding(evt.meta.target)
        end if
        ' By the time playback starts the manifest is parsed, so the track
        ' lists have settled. Signalling readiness this way avoids an
        ' arbitrary timer, and a menu opened earlier can show it is still
        ' loading rather than showing an incomplete list as if it were final.
        if evt.name = "playbackStart" then
            m.top.tracksReady = true
        end if
    end for
    ' Emitted last, so the snapshot each payload carries reflects the state
    ' and position AFTER this transition has been applied - including the
    ' position correction a landed seek just published.
    emitAnalytics(result.events)
end sub

' ==========================================================================
' ANALYTICS
'
' The session already decided which events fired and computed their
' metadata. This only adds the player snapshot and hands the batch to the
' client. That is the whole of P4 - the design work happened in P3.
' ==========================================================================
sub emitAnalytics(events as object)
    if events = invalid or events.count() = 0 then
        return
    end if
    m.analyticsSequence = m.analyticsSequence + 1
    m.top.analyticsEvents = rbp_toAnalyticsBatch(events, {
        timestamp: CreateObject("roDateTime").asSeconds()
        position: m.top.position
        duration: m.top.duration
        state: m.top.playerState
    }, m.analyticsSequence)
end sub

' A seek just landed. Publish the target immediately, bypassing the throttle.
'
' Roku reports position only about once a second, and a seek plus its
' buffering cycle usually consumes that entire window. Without this, a client
' computing a relative seek ("current + 30") reads a position from BEFORE the
' seek and targets the same place again - so the remote appears to stop
' working, which is exactly what P3 testing showed.
'
' The target is approximate: Roku snaps to a segment boundary, so the true
' landed position can be a few seconds earlier. Publishing the requested
' position now and letting the next real tick correct it is both far closer
' than a stale value and closer to what the user expects to see after a seek.
sub publishSeekLanding(target as dynamic)
    if not rbp_isNumeric(target) then
        return
    end if
    ' Zero, not now - the next genuine tick must still be allowed through so
    ' the approximate value gets corrected even when a client has throttling on.
    m.lastPositionMs = 0
    m.top.position = target
end sub

sub publishStats()
    stats = {
        startupMs: startupMs()
        rebufferCount: m.session.rebufferCount
        rebufferMs: m.session.rebufferMs
        droppedCount: m.session.droppedCount
    }
    ' An assocarray field notifies on EVERY assignment - SceneGraph does not
    ' compare the value the way it does for strings and booleans. Publishing
    ' unchanged stats on every state change would wake the client several
    ' times per second with an identical payload, and every one of those
    ' notifications is render-thread work that delays the next one.
    if m.lastStats <> invalid and statsEqual(m.lastStats, stats) then
        return
    end if
    m.lastStats = stats
    m.top.sessionStats = stats
end sub

function statsEqual(a as object, b as object) as boolean
    if a.startupMs <> b.startupMs then
        return false
    end if
    if a.rebufferCount <> b.rebufferCount then
        return false
    end if
    if a.rebufferMs <> b.rebufferMs then
        return false
    end if
    if a.droppedCount <> b.droppedCount then
        return false
    end if
    return true
end function

function startupMs() as integer
    if m.session.firstPlayAtMs <= 0 then
        return 0
    end if
    return m.session.firstPlayAtMs - m.session.startedAtMs
end function

function clockMs() as integer
    return m.clock.TotalMilliseconds()
end function

function formatMeta(meta as object) as string
    if meta = invalid then
        return ""
    end if
    out = ""
    for each key in meta
        if out <> "" then
            out = out + " "
        end if
        out = out + key + "=" + toStrSafe(meta[key])
    end for
    return out
end function

function toStrSafe(value as dynamic) as string
    if value = invalid then
        return "invalid"
    end if
    valueType = type(value)
    if valueType = "Boolean" or valueType = "roBoolean" then
        return value.toStr()
    end if
    if rbp_isNumeric(value) then
        return Str(value).Trim()
    end if
    return value.toStr()
end function

' ==========================================================================
' INTERNAL
' ==========================================================================
function applyAction(action as string) as object
    control = rbp_resolveControl(action, m.top.playerState)
    if control = ""
        ' Not an error - the action simply does not apply in this state.
        return {
            ok: true
            code: "none"
            message: "no-op in state " + m.top.playerState
        }
    end if
    m.wrapper.callFunc("applyControl", control)
    return {
        ok: true
        code: "none"
        message: ""
    }
end function

sub onRawState()
    ' The state machine decides everything: whether this buffering is
    ' start-up or a stall, whether the transition is legal, which events it
    ' implies. This handler only applies the result.
    applySession(rbp_sessionOnRawState(m.session, m.wrapper.rawState, clockMs()))
end sub

sub onWrapperPosition()
    ' Provisional while a seek is in flight. Roku reports the requested
    ' position, then buffers, then corrects to the segment it actually landed
    ' on - a scrubber that trusted it would visibly jump backwards.
    if not rbp_acceptsPosition(m.session) then
        return
    end if
    now = clockMs()
    intervalMs = int(m.top.positionInterval * 1000)
    if not rbp_shouldEmitPosition(m.lastPositionMs, now, intervalMs) then
        return
    end if
    m.lastPositionMs = now
    m.top.position = m.wrapper.position
end sub

sub onWrapperDuration()
    d = m.wrapper.duration
    if d > 0 then
        m.top.duration = d
    end if
end sub

sub onWrapperError()
    e = m.wrapper.videoError
    if e = invalid then
        return
    end if
    if e.code = invalid or e.code = 0 then
        return
    end if
    m.top.errorInfo = {
        code: "mediaError"
        message: "video error " + Str(e.code).Trim() + ": " + e.message
    }
end sub

sub onWrapperAudioTracks()
    m.top.audioTracks = m.wrapper.audioTracks
end sub

sub onWrapperSubtitleTracks()
    m.top.subtitleTracks = m.wrapper.subtitleTracks
end sub

sub onWrapperCaptionMode()
    m.top.captionMode = m.wrapper.captionMode
end sub

sub onSizeChanged()
    m.wrapper.size = m.top.size
end sub